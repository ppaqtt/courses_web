window.TUTORIAL_DATA_fortran = [
  {
    "id": 1,
    "t": "Fortran 语言简介与历史",
    "p": [
      "Fortran 是 Formula Translation 的缩写，1957 年由 IBM 的 Backus 团队发布，是第一个广泛使用的高级语言",
      "现代 Fortran 指 Fortran 90 及以后版本，支持自由格式源码、模块、数组整体运算、派生类型和可分配数组",
      "Fortran 至今仍是数值计算、气象预报、物理模拟和高性能计算的主流语言，BLAS/LAPACK 线性代数库就以其实现",
      "源码扩展名 .f90/.f08 表示自由格式；老式 .f/.for 为固定格式，前 6 列是标号区，第 7 列是续行标志"
    ],
    "c": "program hello\n  implicit none\n  integer :: year\n  year = 1957\n  print '(A)', 'Hello, Fortran!'\n  print '(A,I0)', 'Fortran 诞生于 ', year\n  print '(A)', '这是现代自由格式 Fortran（.f90）示例。'\nend program hello",
    "et": "❌ 常见错误",
    "ec": "把 Fortran 当成只能写固定格式的老语言：.f90 文件是自由格式，语句可以从任意列开始，不需要在第 7 列写续行标记；反过来，把自由格式代码存成 .f 又会导致编译错位。",
    "q": [
      {
        "q": "现代 Fortran 自由格式源文件通常使用什么扩展名？",
        "a": ".f90（或 .f95/.f03/.f08），固定格式则用 .f/.for"
      }
    ]
  },
  {
    "id": 2,
    "t": "安装、编译与运行环境",
    "p": [
      "用 gfortran 编译：gfortran hello.f90 -o hello 生成可执行文件，再执行 ./hello；加 -Wall 可打开常用警告",
      "gfortran 常用选项：-std=f2018 指定标准、-O2 优化、-g 生成调试信息、-fcheck=all 打开运行期检查",
      "fpm（Fortran Package Manager）用 fpm.toml 描述项目，fpm build/run/test 自动处理依赖",
      "编译顺序很重要：被 USE 的模块必须先编译生成 .mod 文件，fpm 或 Makefile 会自动解决这个依赖顺序"
    ],
    "c": "program build_demo\n  implicit none\n  ! 编译：gfortran -O2 -Wall -o build_demo build_demo.f90\n  ! 运行：./build_demo   （或 gfortran build_demo.f90 && ./a.out）\n  ! 查看版本：gfortran --version\n  print '(A)', '环境就绪：已成功编译并运行本程序。'\n  print '(A)', '推荐用 fpm 管理项目：fpm new demo && fpm run'\nend program build_demo",
    "et": "❌ 常见错误",
    "ec": "直接 gfortran main.f90 却报找不到模块文件：因为使用了模块却未把模块源文件一起编译。应写 gfortran mod.f90 main.f90，或用 -I 指定 .mod 所在目录。",
    "q": [
      {
        "q": "用 gfortran 编译 app.f90 并打开所有运行期检查，命令怎么写？",
        "a": "gfortran -g -O0 -fcheck=all -Wall app.f90 -o app"
      }
    ]
  },
  {
    "id": 3,
    "t": "变量、常量与命名规则",
    "p": [
      "每个程序单元开头都要写 implicit none，禁用 i-n 隐式类型规则，否则变量名拼错也不会报错",
      "Fortran 标识符不区分大小写，最长 63 个字符，只能包含字母、数字和下划线，且必须以字母开头",
      "用 integer, parameter :: n = 10 定义编译期常量；普通局部变量在每次进入过程时重新初始化",
      "带 save 属性或声明在模块中的变量生命周期贯穿整个程序，不会随过程返回而销毁"
    ],
    "c": "program vars\n  implicit none\n  integer, parameter :: max_n = 100      ! 编译期常量\n  integer :: count\n  real :: ratio\n  character(len=20) :: name\n  logical :: ok\n  count = 42\n  ratio = 0.75\n  name = 'Fortran'\n  ok = count > 0\n  print '(A,I0,A,I0)', 'count = ', count, ' / max = ', max_n\n  print '(A,F5.2)', 'ratio = ', ratio\n  print '(A,A)', 'name = ', trim(name)\n  print '(A,L1)', 'ok = ', ok\nend program vars",
    "et": "❌ 常见错误",
    "ec": "忘记写 implicit none，把 count 拼成 cuont 后程序仍能编译，变量被隐式当作 integer 且初值不确定，运行结果莫名其妙；另一个常见错误是给 parameter 常量再次赋值，编译直接报错。",
    "q": [
      {
        "q": "Fortran 中定义编译期常量的正确写法是什么？",
        "a": "integer, parameter :: n = 10（声明时加 parameter 属性）"
      }
    ]
  },
  {
    "id": 4,
    "t": "数据类型与类型声明",
    "p": [
      "integer 有 int8/int32/int64 等 kind，用 iso_fortran_env 中的常量声明，如 integer(int64) :: n",
      "real 用 real64（约 15 位有效数字）或 selected_real_kind(15,307) 获得双精度，字面量要带 _real64 后缀",
      "complex 用 (实部, 虚部) 构造，用 z%re / z%im 访问；logical 只有 .true. 与 .false. 两个值",
      "character(len=n) 是定长字符串，赋值不足补空格、超出则截断；character(len=:) 可延迟长度再 allocate"
    ],
    "c": "program types\n  use iso_fortran_env, only: int32, int64, real64\n  implicit none\n  integer(int32) :: i = 2024\n  integer(int64) :: big = 9000000000_int64\n  real(real64) :: x = 3.141592653589793_real64\n  complex :: z = (1.0, 2.0)\n  logical :: flag = .true.\n  character(len=12) :: s = 'typed'\n  print '(A,I0)', 'int32:  ', i\n  print '(A,I0)', 'int64:  ', big\n  print '(A,F0.6)', 'real64: ', x\n  print '(A,F4.1,A,F4.1,A)', 'complex: ', z%re, ' + ', z%im, 'i'\n  print '(A,L1)', 'logical: ', flag\n  print '(A,A)', 'char: ', trim(s)\nend program types",
    "et": "❌ 常见错误",
    "ec": "写 real(8) 而不是 real(real64)：kind 号 8 依赖编译器实现，换平台可能不对。应使用 iso_fortran_env 的命名常量。另外 3.14 默认是单精度，赋给 real64 只保留单精度那几位。",
    "q": [
      {
        "q": "怎样声明一个 64 位整数并赋值为 90 亿？",
        "a": "use iso_fortran_env, only: int64；integer(int64) :: n = 9000000000_int64"
      }
    ]
  },
  {
    "id": 5,
    "t": "运算符与表达式",
    "p": [
      "算术运算符有 + - * / **，其中 ** 优先级最高，/ 与 * 同级从左到右；两个整数相除会截断小数部分",
      "关系运算符可写 < <= > >= == /=，旧式写法 .lt. .le. .gt. .ge. .eq. .ne. 仍然有效",
      "逻辑运算符 .and. .or. .not. .eqv. .neqv. 的优先级低于关系运算，复杂条件应用括号明确结合顺序",
      "mod(a,b) 求余、real(a) 做类型转换；混合类型运算会自动提升，但整数除法陷阱需显式转换避免"
    ],
    "c": "program operators\n  implicit none\n  integer :: a = 7, b = 2\n  real :: x = 2.0\n  print '(A,I0)', '整除 7/2 = ', a / b\n  print '(A,I0)', '取余 mod(7,2) = ', mod(a, b)\n  print '(A,F5.2)', '实除 7.0/2 = ', real(a) / b\n  print '(A,F5.1)', '幂 2**3 = ', x**3\n  print '(A,L1)', '关系 3 < 5 = ', 3 < 5\n  print '(A,L1)', '逻辑 .not. .false. = ', .not. .false.\n  print '(A,L1)', '逻辑 .and. = ', (a > 0) .and. (b > 0)\n  ! / 与 * 同级从左到右，** 优先级最高；整数除法先截断\nend program operators",
    "et": "❌ 常见错误",
    "ec": "用 1/2 期望得到 0.5，实际两个整数相除结果为 0。必须写成 1.0/2 或 real(1)/2。另一个错误是把 .and. 写成 && 或 and，Fortran 不认识这类 C 风格符号。",
    "q": [
      {
        "q": "表达式 7/2 与 7.0/2 的结果分别是多少？",
        "a": "分别是 3（整数截断）和 3.5（实数除法）"
      }
    ]
  },
  {
    "id": 6,
    "t": "字符串处理",
    "p": [
      "character(len=20) 声明定长字符串；len 返回声明长度，len_trim 返回去掉尾部空格后的实际长度",
      "用 // 连接字符串，trim 去尾部空格，adjustl/adjustr 调整对齐；这些函数返回新串而不修改原串",
      "index(s, sub) 返回子串起始位置，找不到返回 0；s(i:j) 是包含两端的切片，越界不会被检查",
      "内部文件读写可完成字符串与数字互转：write(buf,'(I0)') n 输出，read(buf,*) n 解析"
    ],
    "c": "program strings\n  implicit none\n  character(len=20) :: first = 'Fortran'\n  character(len=20) :: last = ' 2023'\n  character(len=64) :: msg\n  integer :: pos\n  msg = trim(first) // ' ' // trim(adjustl(last)) // ' rocks'\n  pos = index(msg, 'rocks')\n  print '(A)', trim(msg)\n  print '(A,I0)', 'len_trim = ', len_trim(msg)\n  print '(A,I0)', '子串位置 = ', pos\n  print '(A,A)', '切片 = ', msg(1:7)\n  msg(1:7) = 'FORTRAN'\n  print '(A)', trim(msg)\n  ! len 是声明长度，trim 去尾空格，adjustl 去左空格\nend program strings",
    "et": "❌ 常见错误",
    "ec": "以为 msg(8:12) 能取出变长内容：切片按声明长度定位，尾部空格仍在。用 trim/len_trim 处理实际内容；另外对定长字符变量赋超长字符串会静默截断，不会报错。",
    "q": [
      {
        "q": "字符串 'Fortran ' 的 len 与 len_trim 结果有何不同？",
        "a": "len 返回声明长度（含尾部空格）；len_trim 返回去掉尾部空格后的长度"
      }
    ]
  },
  {
    "id": 7,
    "t": "数组与数组运算",
    "p": [
      "Fortran 数组下标默认从 1 开始，声明 integer :: a(5) 后合法下标是 1..5，访问 a(0) 属于越界",
      "内存按列优先（column-major）存储，a(i,j) 中 i 变化最快，循环时让内层遍历第一个下标更缓存友好",
      "可分配数组用 integer, allocatable :: a(:) 声明，allocate(a(n)) 分配，deallocate 释放",
      "数组支持整体运算：a = b + 1、sum(a)、maxval(a)、where(a>0) 以及切片 a(2:4) 和隐含 do 构造"
    ],
    "c": "program arrays\n  implicit none\n  integer :: i\n  integer, allocatable :: a(:)\n  integer :: b(5) = [10, 20, 30, 40, 50]\n  allocate(a(5))\n  a = [(i * i, i = 1, 5)]          ! 隐含 do：1 4 9 16 25\n  print '(A,5I4)', 'b =', b\n  print '(A,5I4)', 'a =', a\n  print '(A,I0)', '求和 = ', sum(a)\n  print '(A,I0)', '最大 = ', maxval(a)\n  print '(A,5I4)', '切片 a(2:4) =', a(2:4)\n  print '(A,I0)', '元素个数 = ', size(a)\n  deallocate(a)\n  ! 下标从 1 开始，内存按列优先（column-major）存放\nend program arrays",
    "et": "❌ 常见错误",
    "ec": "按 C 习惯访问 a(0) 或 a(5) 当最后一个元素：Fortran 下标是 1..5，a(0) 和 a(5) 都越界。默认不检查越界，可能读到垃圾值，编译时加 -fcheck=bounds 才能捕获。",
    "q": [
      {
        "q": "声明 integer :: a(5) 后，合法下标范围是多少？",
        "a": "1 到 5（含两端），0 和 6 都越界"
      }
    ]
  },
  {
    "id": 8,
    "t": "条件判断",
    "p": [
      "if 语句必须配 then 和 end if；多分支用 else if ... then，没有 C 语言那种花括号写法",
      "select case 按整型、字符或逻辑值匹配，case (1:5) 表示闭区间，case default 处理其余情况",
      "关系与逻辑表达式返回 logical；条件必须放在括号内，且不能用整数 0/1 代替 .false./.true.",
      "merge(a, b, mask) 可按掩码逐元素选择；block ... end block 可限制临时变量的作用域"
    ],
    "c": "program conditions\n  implicit none\n  integer :: score = 86\n  character(len=8) :: grade\n  if (score >= 90) then\n     grade = 'A'\n  else if (score >= 80) then\n     grade = 'B'\n  else\n     grade = 'C'\n  end if\n  print '(A,I0,A,A)', 'score=', score, ' grade=', trim(grade)\n  select case (score / 10)\n  case (9)\n     print '(A)', '优秀'\n  case (8)\n     print '(A)', '良好'\n  case default\n     print '(A)', '继续努力'\n  end select\n  ! if 必须写 then/end if；select case 不会贯穿到下一个分支\nend program conditions",
    "et": "❌ 常见错误",
    "ec": "写 if (x > 0) x = 1 这种单行形式却漏掉 then，编译报错；还有人在 select case 里期待 C 的 fall-through，Fortran 匹配一个 case 后立即跳出，不会继续执行下一个分支。",
    "q": [
      {
        "q": "Fortran 的 select case 匹配到某个 case 后会自动继续执行下一个 case 吗？",
        "a": "不会，执行完该分支后直接跳到 end select"
      }
    ]
  },
  {
    "id": 9,
    "t": "循环结构",
    "p": [
      "计数循环 do i = 1, 10, 2 含起始值、终止值和步长，循环体以 end do 结束，步长可以为负",
      "do while (条件) 在条件为真时重复；循环可命名（outer: do）以便 cycle outer / exit outer 精确跳转",
      "cycle 跳过本轮剩余语句，exit 立即退出当前循环；不带标签时只作用于最内层循环",
      "Fortran 2008 的 do concurrent 表示各迭代之间无依赖，编译器可用 OpenMP 或向量化并行执行"
    ],
    "c": "program loops\n  implicit none\n  integer :: i, total\n  total = 0\n  do i = 1, 10\n     total = total + i\n  end do\n  print '(A,I0)', '1..10 求和 = ', total\n  i = 1\n  do while (i <= 5)\n     print '(A,I0)', 'while i=', i\n     i = i + 1\n  end do\n  outer: do i = 1, 3\n     if (i == 2) cycle outer\n     print '(A,I0)', 'do i=', i\n  end do outer\n  ! do concurrent 表示迭代无依赖，可被并行化\nend program loops",
    "et": "❌ 常见错误",
    "ec": "在 do 循环体内手动修改循环变量 i（如 i = i + 1），Fortran 规定循环变量由循环控制，修改会导致迭代次数不确定，gfortran 优化后可能只执行一次。需要提前退出请用 exit。",
    "q": [
      {
        "q": "循环中跳过本次剩余语句并进入下一轮，应使用哪个关键字？",
        "a": "cycle（带标签可作用于指定外层循环）"
      }
    ]
  },
  {
    "id": 10,
    "t": "函数与子程序基础",
    "p": [
      "函数用 [类型] function name(args) result(r) 定义，通过 result 变量返回结果，调用处直接出现在表达式中",
      "子程序用 subroutine / end subroutine 定义，通过 call 调用；contains 内的内部过程可访问宿主变量",
      "形参用 intent(in)、intent(out)、intent(inout) 声明意图，纯函数加 pure，便于编译期检查和优化",
      "内部过程写在 program 的 contains 之后、end program 之前；外部过程需单独编译或显式写接口"
    ],
    "c": "program procedures\n  implicit none\n  integer :: n = 5\n  print '(A,I0)', 'square(5) = ', square(n)\n  call show_sum(3, 4)\ncontains\n  pure integer function square(x) result(y)\n    integer, intent(in) :: x\n    y = x * x\n  end function square\n\n  subroutine show_sum(a, b)\n    integer, intent(in) :: a, b\n    print '(A,I0)', 'sum = ', a + b\n  end subroutine show_sum\nend program procedures",
    "et": "❌ 常见错误",
    "ec": "把内部过程写在 end program 之后，编译器报 “Unexpected end of file”。contains 里的过程必须位于 end program 之前。另一个错误是函数忘了给 result 变量赋值，返回值是未定义的。",
    "q": [
      {
        "q": "内部过程（contains 之后的过程）应该放在什么位置？",
        "a": "放在 contains 与 end program 之间，不能写到 end program 之后"
      }
    ]
  },
  {
    "id": 11,
    "t": "函数进阶：参数传递、可选参数与重载",
    "p": [
      "可选参数用 integer, optional :: n 声明，过程内用 present(n) 判断是否传入，调用时可省略该实参",
      "关键字实参 call sub(b=2, a=1) 按名字匹配，可读性更好；位置实参必须出现在关键字实参之前",
      "用 interface 定义泛型接口，把 swap_int 与 swap_real 绑定到同一名字 swap，实现编译期重载",
      "递归过程必须加 recursive 关键字，否则局部变量行为未定义；每次递归调用的局部变量相互独立"
    ],
    "c": "program advanced_proc\n  implicit none\n  interface swap\n     procedure :: swap_int, swap_real\n  end interface swap\n  integer :: a = 1, b = 2\n  real :: x = 1.5, y = 2.5\n  call swap(a, b)\n  call swap(x, y)\n  print '(A,2I3)', 'ints: ', a, b\n  print '(A,2F5.1)', 'reals: ', x, y\ncontains\n  subroutine swap_int(p, q)\n    integer, intent(inout) :: p, q\n    integer :: t\n    t = p; p = q; q = t\n  end subroutine swap_int\n  subroutine swap_real(p, q)\n    real, intent(inout) :: p, q\n    real :: t\n    t = p; p = q; q = t\n  end subroutine swap_real\nend program advanced_proc",
    "et": "❌ 常见错误",
    "ec": "递归函数漏写 recursive 关键字，gfortran 会把局部变量放到静态存储区，递归结果错乱；另外可选参数未用 present() 判断就直接使用，未传入时访问到无效地址。",
    "q": [
      {
        "q": "判断可选参数 n 是否被传入用哪个函数？",
        "a": "present(n)，返回 .true. 表示调用方传入了该实参"
      }
    ]
  },
  {
    "id": 12,
    "t": "作用域、模块与封装",
    "p": [
      "module 把数据与过程封装在一起，用 use 导入；private 设为默认访问控制，public 显式导出接口",
      "use mod, only: name 只导入需要的名字，避免不同模块同名符号冲突；可配合 rename 列表重命名",
      "模块变量具有 save 语义，生命周期是整个程序；过程内普通局部变量默认在每次调用时重新初始化",
      "host association 让内部过程直接看到宿主作用域变量，但过度使用会降低可读性，建议显式传参"
    ],
    "c": "module counter_mod\n  implicit none\n  private\n  public :: bump, count\n  integer, save :: count = 0\ncontains\n  subroutine bump()\n    count = count + 1\n  end subroutine bump\nend module counter_mod\n\nprogram scope_demo\n  use counter_mod, only: bump, count\n  implicit none\n  call bump()\n  call bump()\n  print '(A,I0)', 'count = ', count\n  ! private 隐藏实现细节，use ... only 限制导入范围\nend program scope_demo",
    "et": "❌ 常见错误",
    "ec": "模块默认 public 时所有内部符号都会暴露，容易重名冲突；另一常见问题是把模块变量当局部变量，以为每次调用都从初值开始，实际它一直保留上次的值。",
    "q": [
      {
        "q": "模块中怎样把符号默认隐藏、只导出指定接口？",
        "a": "在模块开头写 private，再用 public :: 名称 显式导出"
      }
    ]
  },
  {
    "id": 13,
    "t": "结构化程序设计：派生类型",
    "p": [
      "派生类型用 type :: student ... end type 定义，成员可以是标量、数组或可分配数组",
      "用 % 访问成员，如 s%name；整个记录可整体赋值 s2 = s1，含可分配成员时会自动深拷贝",
      "类型可包含 type-bound procedure 与 contains 块，实现类似面向对象的方法绑定，extends 支持继承",
      "记录数组用 type(student), allocatable :: list(:) 声明，再 allocate 使用；Fortran 没有匿名结构体"
    ],
    "c": "program derived_types\n  implicit none\n  type :: student\n     character(len=20) :: name\n     integer :: age\n     real :: score\n  end type student\n  type(student) :: s\n  type(student), allocatable :: list(:)\n  s%name = 'Li Ming'\n  s%age = 20\n  s%score = 91.5\n  print '(A,A,A,I0,A,F4.1)', '姓名=', trim(s%name), ' 年龄=', s%age, ' 成绩=', s%score\n  allocate(list(2))\n  list(1) = s\n  list(2)%name = 'Wang Fang'\n  list(2)%age = 21\n  list(2)%score = 88.0\n  print '(A,I0)', '记录数 = ', size(list)\n  ! 用 % 访问成员；派生类型可绑定类型方法（type-bound procedure）\nend program derived_types",
    "et": "❌ 常见错误",
    "ec": "定义派生类型时漏写 end type，或把类型定义写在 program 内部却期望其他程序单元也能 use。类型定义应放在 module 中；此外对可分配成员做整体赋值才会深拷贝，指针成员只复制地址。",
    "q": [
      {
        "q": "访问派生类型变量 s 的成员 name 用什么语法？",
        "a": "s%name（百分号是 Fortran 的成员访问运算符）"
      }
    ]
  },
  {
    "id": 14,
    "t": "文件与顺序 I/O",
    "p": [
      "open(unit=10, file='a.txt', status='replace', action='write') 打开文件，close 关闭",
      "顺序格式化文件用 read/write 加格式串；iostat 返回 0 成功、负值表示文件结束、正值表示错误",
      "stream 格式（access='stream'）按字节读写，适合二进制文件；form='unformatted' 则按记录读写",
      "newunit= 让系统分配空闲 unit 号，比硬编码 10/20 更安全，尤其在库代码和多文件并发时"
    ],
    "c": "program file_io\n  implicit none\n  integer :: i, ios, v\n  open(unit=10, file='data.txt', status='replace', action='write')\n  do i = 1, 5\n     write(10, '(I0)') i * 10\n  end do\n  close(10)\n  open(unit=10, file='data.txt', status='old', action='read')\n  do\n     read(10, '(I10)', iostat=ios) v\n     if (ios /= 0) exit\n     print '(A,I0)', '读到: ', v\n  end do\n  close(10, status='keep')\n  ! iostat < 0 表示文件结束，> 0 表示读取错误\nend program file_io",
    "et": "❌ 常见错误",
    "ec": "用 status='old' 打开不存在的文件导致运行时错误终止；写文件后忘了 close 就去读，缓冲区未刷新可能读到空内容。应在每次 open/read 后用 iostat 检查并妥善 close。",
    "q": [
      {
        "q": "顺序读取文件时，iostat 为负值通常意味着什么？",
        "a": "已到达文件末尾（EOF）"
      }
    ]
  },
  {
    "id": 15,
    "t": "错误处理与状态码",
    "p": [
      "I/O 语句加 iostat=ios 与 iomsg=msg，可在不终止程序的情况下获知错误码和错误描述",
      "open 失败（文件不存在、权限不足）返回正的 iostat；read 到文件末尾返回负值，应据此退出循环",
      "也可用 err=100 标签跳转处理错误，但标签式跳转破坏结构化流程，现代代码优先使用 iostat",
      "allocate 加 stat= 可检测内存分配失败；stop 1 向操作系统返回非零退出码，便于脚本判断成败"
    ],
    "c": "program errors\n  implicit none\n  integer :: ios, v\n  character(len=80) :: iomsg\n  character(len=10) :: text\n  open(unit=20, file='missing.txt', status='old', action='read', &\n       iostat=ios, iomsg=iomsg)\n  if (ios /= 0) then\n     print '(A,I0)', '打开失败，iostat=', ios\n     print '(A,A)', '原因: ', trim(iomsg)\n  end if\n  text = 'abc'\n  read(text, *, iostat=ios) v\n  print '(A,I0)', '非法输入 iostat=', ios\n  ! 用 iostat 代替 err= 标签，流程更清晰、更易测试\nend program errors",
    "et": "❌ 常见错误",
    "ec": "只检查“文件能否打开”却忽略 read 的返回值，遇到坏数据或提前 EOF 时程序继续用未初始化变量计算。每个可能失败的 I/O 语句都应检查 iostat，并在失败分支给出明确处理。",
    "q": [
      {
        "q": "open 语句中用于接收错误信息文本的参数是哪个？",
        "a": "iomsg=字符变量（配合 iostat 使用）"
      }
    ]
  },
  {
    "id": 16,
    "t": "格式化输入输出",
    "p": [
      "格式串 '(A,I5,F8.3)' 中 A 输出字符、I5 输出宽度 5 的整数、F8.3 输出 8 列含 3 位小数",
      "I0 表示最小宽度不补空格，ES12.4 为科学计数法，EN 为工程计数法，G 为通用格式",
      "nX 跳过 n 列，T20 定位到第 20 列，/ 表示换行，重复计数如 3I4 表示连续三个 I4 编辑描述符",
      "write(字符串变量, 格式) 是内部文件写，可把数字格式化成字符串；read 则反向解析字符串内容"
    ],
    "c": "program format_io\n  implicit none\n  integer :: n = 42\n  real :: x = 3.14159\n  character(len=30) :: line\n  print '(A,I5)', '整数右对齐: ', n\n  print '(A,I0)', '最小宽度: ', n\n  print '(A,F8.3)', '定点小数: ', x\n  print '(A,ES12.4)', '科学计数: ', x\n  print '(A,2(A,F6.2))', '对齐: ', 'a=', 1.5, ' b=', 2.25\n  write(line, '(A,F7.2)') 'total=', 12.5\n  print '(A,A)', '内部文件: ', trim(line)\n  ! A 输出字符，I0 不补空格，nX 跳过 n 列，/ 换行\nend program format_io",
    "et": "❌ 常见错误",
    "ec": "格式串与实参类型不匹配，例如用 I5 输出 real 变量，编译能过但运行结果乱码或报 “Bad value during integer read”。务必让 I/F/A/L 描述符与实际类型一一对应。",
    "q": [
      {
        "q": "要输出宽度 8、保留 3 位小数的实数，格式描述符怎么写？",
        "a": "F8.3"
      }
    ]
  },
  {
    "id": 17,
    "t": "数值计算与精度",
    "p": [
      "实数精度由 kind 决定：real32 约 7 位有效数字，real64 约 15 位；字面量必须带相应 kind 后缀",
      "浮点数不能用 == 直接比较，应判断 abs(a-b) <= eps；epsilon(x) 给出该精度的机器 epsilon",
      "整数溢出不会报错而是回绕，大数运算应选 int64 或先用 real 估算范围，避免中间结果越界",
      "求和大量浮点数时可用 Kahan 补偿求和或两两求和减小误差；金融金额宜用整数分表示"
    ],
    "c": "program precision\n  use iso_fortran_env, only: real32, real64\n  implicit none\n  real(real32) :: a = 0.1_real32\n  real(real64) :: b = 0.1_real64\n  real(real64) :: sum64 = 0.0_real64\n  integer :: i\n  print '(A,ES12.4)', 'real32 0.1 = ', a\n  print '(A,ES16.8)', 'real64 0.1 = ', b\n  if (abs(a - 0.1_real32) > 0.0_real32) print '(A)', 'real32 存在表示误差'\n  do i = 1, 10\n     sum64 = sum64 + 0.1_real64\n  end do\n  print '(A,F12.10)', '10 次累加 = ', sum64\n  print '(A,ES12.4)', 'epsilon(real64) = ', epsilon(1.0_real64)\n  ! 浮点比较用容差；金额可用整数分或定点方案\nend program precision",
    "et": "❌ 常见错误",
    "ec": "用 if (0.1 + 0.2 == 0.3) 判断相等，结果恒为假，因为二进制浮点无法精确表示这些十进制小数。应写成 abs((0.1+0.2)-0.3) < 1e-12 这样的容差比较。",
    "q": [
      {
        "q": "比较两个浮点计算结果是否相等，推荐的做法是什么？",
        "a": "判断两者差的绝对值是否小于给定容差，如 abs(a-b) < 1e-12"
      }
    ]
  },
  {
    "id": 18,
    "t": "日期与时间处理",
    "p": [
      "date_and_time(values=v) 返回 8 元素数组：年、月、日、时区分钟、时、分、秒、毫秒",
      "system_clock(t, rate) 读取单调时钟计数，elapsed = real(t2-t1)/rate 得到秒数，适合测量耗时",
      "cpu_time 返回处理器时间而非墙上时间，多线程下会累加各线程 CPU 时间，不能当秒表使用",
      "Fortran 标准没有日历运算与时区转换库，复杂日期计算常借助 C 的 strftime 或第三方日期库"
    ],
    "c": "program date_time\n  use iso_fortran_env, only: int64, real64\n  implicit none\n  integer :: v(8), i, s\n  integer(int64) :: t1, t2, rate\n  call date_and_time(values=v)\n  print '(A,I0.4,A,I0.2,A,I0.2)', '日期: ', v(1), '-', v(2), '-', v(3)\n  print '(A,I0.2,A,I0.2,A,I0.2)', '时间: ', v(5), ':', v(6), ':', v(7)\n  print '(A,I0)', '时区偏移(分钟): ', v(4)\n  call system_clock(t1, rate)\n  s = 0\n  do i = 1, 1000000\n     s = s + i\n  end do\n  call system_clock(t2)\n  print '(A,F10.6,A)', '耗时: ', real(t2 - t1, real64) / rate, ' 秒'\n  ! values 依次为年/月/日/时区/时/分/秒/毫秒\nend program date_time",
    "et": "❌ 常见错误",
    "ec": "用 cpu_time 测量包含文件读写或网络等待的耗时，得到的时间远小于真实经过时间，因为它只统计 CPU 执行时间；测量墙上时间应使用 system_clock。",
    "q": [
      {
        "q": "测量一段代码的真实墙上时间，应使用哪个内置子程序？",
        "a": "system_clock（配合 rate 把计数换算成秒）"
      }
    ]
  },
  {
    "id": 19,
    "t": "字符与编码",
    "p": [
      "字符在 Fortran 中是单字节序列，ASCII 环境用 iachar/achar 转码，CHAR/ICHAR 依赖处理器字符集",
      "UTF-8 中文占 3 个字节，len 返回字节数而非字符数；按字符截取需自行解码，否则会截断多字节序列",
      "achar(10) 是换行、achar(9) 是制表符、achar(0) 是空字符；写二进制文件时注意不要误加空字符",
      "比较字符串按字符编码逐位进行，短串补空格后比较；排序非 ASCII 文本需先统一编码（推荐 UTF-8）"
    ],
    "c": "program chars\n  implicit none\n  character(len=:), allocatable :: s\n  integer :: i\n  s = 'A中B'                     ! UTF-8 下“中”占 3 个字节\n  print '(A,I0)', 'len 字节长度 = ', len(s)\n  print '(A,I0)', 'len_trim 字节长度 = ', len_trim(s)\n  do i = 1, len(s)\n     print '(A,I0,A,I0)', 'byte(', i, ') = ', iachar(s(i:i))\n  end do\n  print '(A,A)', '小写转大写: ', char(iachar('a') - 32)\n  ! achar/iachar 按 ASCII 码转换；多字节字符不能用单字节下标切割\nend program chars",
    "et": "❌ 常见错误",
    "ec": "用 s(1:2) 截取 UTF-8 中文，得到半个字符的非法字节序列，显示为乱码。UTF-8 下每个汉字占 3 字节，必须按变长编码解码，或改用 Unicode 库处理字符边界。",
    "q": [
      {
        "q": "UTF-8 编码下，len('中') 的值通常是多少？",
        "a": "3（一个汉字占 3 个字节，len 返回字节数）"
      }
    ]
  },
  {
    "id": 20,
    "t": "模块、库与包管理",
    "p": [
      "module 是 Fortran 的封装与依赖单元，编译后生成 .mod 接口文件，使用方编译时必须能找到它",
      "fpm 项目用 fpm.toml 声明 name、version、依赖与可执行目标，fpm build 自动推导编译顺序",
      "第三方库可在 fpm.toml 的 [dependencies] 中写 git 地址或本地路径，也可链接系统库",
      "模块文件名不必与模块名相同，但约定保持一致（math_utils.f90 含 module math_utils）便于维护"
    ],
    "c": "module math_utils\n  implicit none\n  private\n  public :: mean\ncontains\n  real function mean(x) result(m)\n    real, intent(in) :: x(:)\n    m = sum(x) / size(x)\n  end function mean\nend module math_utils\n\nprogram modules\n  use math_utils, only: mean\n  implicit none\n  real :: data(4) = [1.0, 2.0, 3.0, 4.0]\n  print '(A,F6.2)', '平均值 = ', mean(data)\n  ! 多文件：gfortran math_utils.f90 main.f90 -o app\n  ! 或用 fpm：在 fpm.toml 声明依赖，fpm build 自动排序\nend program modules",
    "et": "❌ 常见错误",
    "ec": "把模块和主程序写在同一文件却先编译主程序，或只提交 .f90 而漏掉 fpm.toml/依赖声明，导致他人编译时找不到 .mod 文件。模块文件应参与同一次构建并先于使用方编译。",
    "q": [
      {
        "q": "gfortran 编译使用模块的程序时，如果报找不到 .mod 文件，通常是什么原因？",
        "a": "包含该模块的源文件没有一起编译，或 .mod 所在目录未用 -I 指定"
      }
    ]
  },
  {
    "id": 21,
    "t": "标准库速查与工具链",
    "p": [
      "编译运行：gfortran -O2 -Wall app.f90 -o app && ./app；调试版加 -g -O0 -fcheck=all",
      "包管理：fpm new demo 创建项目，fpm build 编译，fpm run 运行，fpm test 执行测试",
      "测试框架：test-drive 提供 assert/check，pFUnit 为 JUnit 风格；格式化用 findent 或 fprettify",
      "调试器 gdb ./app 支持 break 文件:行号、print 变量、next/step 单步；编译时必须加 -g"
    ],
    "c": "program toolchain\n  use iso_fortran_env, only: compiler_version, compiler_options\n  implicit none\n  print '(A)', '编译器: ' // trim(compiler_version())\n  print '(A)', '编译选项: ' // trim(compiler_options())\n  ! 工具链速查：\n  !   编译运行  gfortran -O2 -Wall app.f90 -o app && ./app\n  !   包管理    fpm new demo / fpm build / fpm run / fpm test\n  !   测试框架  test-drive（fpm 依赖）或 pFUnit\n  !   格式化    findent < in.f90 > out.f90；fprettify -i 3 file.f90\n  !   调试器    gdb ./app  （用 gfortran -g -O0 编译）\nend program toolchain",
    "et": "❌ 常见错误",
    "ec": "只写 gfortran app.f90 不带任何警告与检查选项，越界、未初始化变量等问题被掩盖；发布构建应加 -O2 -Wall -Wextra，测试构建应加 -fcheck=all -ffpe-trap=invalid。",
    "q": [
      {
        "q": "用 fpm 创建、构建并测试一个新项目的三条命令是什么？",
        "a": "fpm new demo；fpm build；fpm test"
      }
    ]
  },
  {
    "id": 22,
    "t": "并发与并行",
    "p": [
      "OpenMP 用编译指令并行化循环：!$omp parallel do reduction(+:s) 把迭代分配到多个线程",
      "编译需加 -fopenmp，运行前用 OMP_NUM_THREADS 控制线程数；循环迭代之间必须没有数据依赖",
      "coarray（Fortran 2008）提供原生并行：用 [*] 声明共数组，sync all 同步，编译选项依编译器而定",
      "MPI 是分布式内存并行的主流方案，Fortran 绑定成熟，适用于跨节点的大规模数值模拟"
    ],
    "c": "program openmp_demo\n  implicit none\n  integer, parameter :: n = 1000000\n  integer :: i\n  real(8) :: s, x\n  s = 0.0d0\n  !$omp parallel do reduction(+:s) private(x)\n  do i = 1, n\n     x = 1.0d0 / real(i, 8)\n     s = s + x\n  end do\n  !$omp end parallel do\n  print '(A,F12.6)', '调和级数部分和 = ', s\n  ! 编译：gfortran -fopenmp openmp_demo.f90 -o demo\n  ! 线程数：export OMP_NUM_THREADS=4\nend program openmp_demo",
    "et": "❌ 常见错误",
    "ec": "忘记加 -fopenmp，!$omp 指令被当作注释，程序串行执行却以为已并行；另一错误是循环存在跨迭代依赖（如累加未加 reduction），并行结果错误且难以复现。",
    "q": [
      {
        "q": "OpenMP 并行循环中多个线程累加同一变量，应使用哪个子句？",
        "a": "reduction(+:变量名)，为每个线程生成私有副本再合并"
      }
    ]
  },
  {
    "id": 23,
    "t": "性能优化",
    "p": [
      "按列优先顺序遍历数组，内层循环让第一个下标连续变化，可显著减少缓存未命中",
      "尽量使用整体数组运算（a = b + c）与内置函数 sum/matmul，编译器更容易向量化",
      "编译加 -O2/-O3、-march=native 启用指令集优化；用 -fopt-info-vec 查看向量化报告",
      "避免在循环内反复分配/释放可分配数组或拼接字符串；预分配缓冲区并复用，减少堆开销"
    ],
    "c": "program performance\n  implicit none\n  integer, parameter :: n = 2000\n  real(8), allocatable :: a(:,:)\n  integer :: i, j\n  real(8) :: t1, t2, total\n  allocate(a(n, n))\n  a = 1.0d0\n  call cpu_time(t1)\n  total = 0.0d0\n  do j = 1, n          ! 外层列、内层行：访问连续内存\n     do i = 1, n\n        total = total + a(i, j)\n     end do\n  end do\n  call cpu_time(t2)\n  print '(A,ES12.4)', '按列访问求和 = ', total\n  print '(A,F10.4,A)', '耗时 = ', t2 - t1, ' 秒'\n  ! 列优先：a(i,j) 中 i 变化最快；sum(a) 更易向量化\nend program performance",
    "et": "❌ 常见错误",
    "ec": "沿用 C 习惯把外层写成行、内层写列（do i 在外、do j 在内），每次访问跨越 n 个元素，缓存命中率骤降。Fortran 应让内层循环遍历第一个下标。",
    "q": [
      {
        "q": "二维数组 a(i,j) 按列优先存储时，哪个下标变化对应连续内存？",
        "a": "第一个下标 i，因此内层循环应遍历 i"
      }
    ]
  },
  {
    "id": 24,
    "t": "测试与验证",
    "p": [
      "单元测试应覆盖正常值、边界值与非法输入；把被测逻辑写成 pure function 便于独立测试",
      "test-drive 用 check(条件, 消息) 收集断言结果，fpm test 会自动构建并运行测试程序",
      "浮点断言应带容差，如 abs(x-expected) < 1e-10；不要用 == 比较计算结果",
      "编译加 -fcheck=all -ffpe-trap=invalid,zero,overflow，可把隐藏越界与浮点异常暴露在测试阶段"
    ],
    "c": "program tests\n  implicit none\n  integer :: failed\n  failed = 0\n  if (add(2, 3) /= 5) failed = failed + 1\n  if (add(-1, 1) /= 0) failed = failed + 1\n  if (fact(5) /= 120) failed = failed + 1\n  if (abs(sqrt(2.0d0)**2 - 2.0d0) > 1.0d-12) failed = failed + 1\n  if (failed == 0) then\n     print '(A)', '全部测试通过'\n  else\n     print '(A,I0)', '失败用例数 = ', failed\n     stop 1\n  end if\ncontains\n  integer function add(a, b) result(r)\n    integer, intent(in) :: a, b\n    r = a + b\n  end function add\n  recursive integer function fact(n) result(r)\n    integer, intent(in) :: n\n    if (n <= 1) then; r = 1; else; r = n * fact(n - 1); end if\n  end function fact\nend program tests",
    "et": "❌ 常见错误",
    "ec": "测试只覆盖 2+3=5 这类正常值，边界（0、负数、最大值）不测；浮点结果用 == 判断导致偶发失败。应加入边界用例并用容差比较，失败时以非零退出码结束。",
    "q": [
      {
        "q": "为什么测试中不应用 == 比较浮点计算结果？",
        "a": "浮点存在舍入误差，应改用 abs(a-b) < 容差 的方式判断"
      }
    ]
  },
  {
    "id": 25,
    "t": "调试技巧",
    "p": [
      "用 -g -O0 编译以保留符号与行号，gdb 中 break file.f90:12 下断点，print 变量、bt 查看调用栈",
      "-fcheck=bounds 检查数组越界，-fcheck=all 还检查指针与可分配对象；-Wall -Wextra 报告可疑代码",
      "在关键分支插入 print 或 write(error_unit,*) 输出中间值，error_unit 不会污染标准输出",
      "调试与优化选项冲突：-O2 会重排变量，调试阶段用 -O0 -g，定位后再开优化验证问题是否仍存在"
    ],
    "c": "program debug_demo\n  implicit none\n  integer :: i, total\n  total = 0\n  do i = 1, 5\n     total = total + i\n     if (total > 10) print '(A,I0,A,I0)', '[debug] i=', i, ' total=', total\n  end do\n  print '(A,I0)', '结果 = ', total\n  ! 调试编译：gfortran -g -O0 -fcheck=all -ffpe-trap=invalid,zero debug_demo.f90\n  ! gdb ./a.out → break debug_demo.f90:7 / print total / next\n  ! -fcheck=all 捕获越界，-Wall -Wextra 捕获可疑代码\nend program debug_demo",
    "et": "❌ 常见错误",
    "ec": "用 -O2 编译后调试，变量被优化掉，gdb 显示 optimized out，断点位置也跳来跳去。调试必须用 -O0 -g；另外不开 -fcheck 时数组越界不会报错，只会得到诡异结果。",
    "q": [
      {
        "q": "gdb 中查看函数调用栈使用哪条命令？",
        "a": "bt（backtrace）"
      }
    ]
  },
  {
    "id": 26,
    "t": "与 C 及系统接口互操作（iso_c_binding）",
    "p": [
      "iso_c_binding 定义 c_int、c_double、c_char、c_ptr 等 kind，保证与 C 类型在二进制层面兼容",
      "用 interface + bind(C, name='strlen') 声明 C 函数；标量参数加 value 属性按值传递，否则默认传地址",
      "C 字符串以 c_null_char 结尾，Fortran 字符串不会自动添加，需手动拼接并注意缓冲区长度",
      "链接 C 库用 -l 选项，如 gfortran app.f90 -lsqlite3；反过来 C 调用 Fortran 时用 bind(C) 导出过程"
    ],
    "c": "program c_interop\n  use iso_c_binding, only: c_char, c_null_char, c_size_t\n  implicit none\n  interface\n     function c_strlen(s) bind(C, name='strlen') result(n)\n       import :: c_char, c_size_t\n       character(kind=c_char), intent(in) :: s(*)\n       integer(c_size_t) :: n\n     end function c_strlen\n  end interface\n  character(kind=c_char, len=32) :: name\n  name = 'Fortran' // c_null_char\n  print '(A,I0)', 'C strlen 结果 = ', c_strlen(name)\n  ! C 字符串以 c_null_char 结尾；value 属性表示按值传参\nend program c_interop",
    "et": "❌ 常见错误",
    "ec": "把 Fortran 字符串直接传给期望 C 字符串的函数却忘了 c_null_char，C 会一直读到内存垃圾才停止；另外漏写 bind(C) 时编译器按 Fortran 约定传隐藏长度参数，C 函数收到错误实参。",
    "q": [
      {
        "q": "Fortran 调用 C 的 strlen 时，字符串末尾必须补上什么？",
        "a": "c_null_char（即 NUL 字符），否则 C 无法判断字符串结束"
      }
    ]
  },
  {
    "id": 27,
    "t": "设计模式与程序组织",
    "p": [
      "用模块封装一族算法，通过 abstract interface 定义过程签名，procedure 指针在运行期选择具体实现",
      "策略模式用 procedure(op_iface) :: f 传入不同函数，避免冗长的 select case 分支",
      "工厂/多态可用返回 class 指针的函数配合 select type 做动态类型分派，实现运行期多态",
      "Fortran 没有命名空间，靠 module + private/public 模拟；每个模块只暴露最小接口是大型项目的关键"
    ],
    "c": "module strategies\n  implicit none\n  abstract interface\n     real function op_iface(x) result(y)\n       real, intent(in) :: x\n     end function op_iface\n  end interface\ncontains\n  real function apply(f, x) result(y)\n    procedure(op_iface) :: f\n    real, intent(in) :: x\n    y = f(x)\n  end function apply\n  real function dbl(x) result(y)\n    real, intent(in) :: x\n    y = 2.0 * x\n  end function dbl\nend module strategies\nprogram patterns\n  use strategies\n  implicit none\n  procedure(op_iface), pointer :: p => null()\n  p => dbl\n  print '(A,F5.1)', 'apply(dbl, 3.5) = ', apply(p, 3.5)\nend program patterns",
    "et": "❌ 常见错误",
    "ec": "把过程指针声明成 procedure(op_iface) 却漏掉 pointer 属性，赋值 p => dbl 编译报错；或在 apply 中对哑元过程未写 procedure(op_iface) 接口，编译器无法检查签名是否匹配。",
    "q": [
      {
        "q": "Fortran 中用于声明“过程指针”的属性关键字是什么？",
        "a": "pointer，配合 procedure(接口名) :: p 使用"
      }
    ]
  },
  {
    "id": 28,
    "t": "数据库访问（SQLite C 接口）",
    "p": [
      "Fortran 标准不含数据库 API，常见做法是通过 iso_c_binding 调用 SQLite/ODBC 的 C 接口",
      "SQLite 的 C API 很简单：sqlite3_open、sqlite3_exec、sqlite3_close，编译时用 -lsqlite3 链接",
      "企业环境常用 ODBC 或 PostgreSQL 的 libpq；也可以让程序输出 CSV，由外部工具批量导入数据库",
      "拼接 SQL 字符串时要转义单引号防止注入，更安全的做法是使用预处理语句绑定参数"
    ],
    "c": "program sqlite_demo\n  use iso_c_binding; implicit none\n  type(c_ptr) :: db, msg; integer(c_int) :: rc\n  interface\n     function sqlite3_open(fn, pp) bind(C, name='sqlite3_open') result(r)\n       import :: c_char, c_ptr, c_int\n       character(kind=c_char), intent(in) :: fn(*); type(c_ptr), intent(out) :: pp\n       integer(c_int) :: r\n     end function sqlite3_open\n     function sqlite3_exec(d, s, cb, a, em) bind(C, name='sqlite3_exec') result(r)\n       import :: c_char, c_ptr, c_int\n       type(c_ptr), value :: d, cb, a; character(kind=c_char), intent(in) :: s(*)\n       type(c_ptr), intent(out) :: em; integer(c_int) :: r\n     end function sqlite3_exec\n     subroutine sqlite3_close(d) bind(C, name='sqlite3_close')\n       import :: c_ptr\n       type(c_ptr), value :: d\n     end subroutine sqlite3_close\n  end interface\n  rc = sqlite3_open('demo.db'//c_null_char, db)\n  rc = sqlite3_exec(db, \"DROP TABLE IF EXISTS t;CREATE TABLE t(v INT);\"// &\n       \"INSERT INTO t VALUES(1)\"//c_null_char, c_null_ptr, c_null_ptr, msg)\n  print '(A,I0)', 'exec 返回码 = ', rc\n  call sqlite3_close(db)\nend program sqlite_demo",
    "et": "❌ 常见错误",
    "ec": "编译时忘记加 -lsqlite3，链接阶段报 undefined reference；另一错误是 SQL 字符串没有以 c_null_char 结尾，C 接口读到越界内存，返回错误或崩溃。",
    "q": [
      {
        "q": "用 gfortran 编译调用 SQLite C 接口的程序，链接选项是什么？",
        "a": "-lsqlite3（并确保系统已安装 sqlite3 开发库）"
      }
    ]
  },
  {
    "id": 29,
    "t": "网络编程与 HTTP 请求",
    "p": [
      "Fortran 没有内置套接字，HTTP 请求常通过 execute_command_line 调用 curl，或绑定 libcurl 的 C 接口",
      "execute_command_line 的 exitstat 返回命令退出码，非 0 表示失败，应检查后再读取响应文件",
      "更健壮的做法是用 iso_c_binding 绑定 POSIX socket 或 libcurl，避免依赖外部命令与临时文件",
      "解析响应时注意状态行、头部与正文的分离；生产代码需设置超时、限制响应大小并校验状态码"
    ],
    "c": "program http_demo\n  implicit none\n  integer :: ios, unit\n  character(len=200) :: line\n  ! Fortran 无内置套接字，常用外部工具或 C 库发 HTTP 请求\n  call execute_command_line('curl -s -m 5 https://example.com -o page.html', exitstat=ios)\n  print '(A,I0)', 'curl 退出码 = ', ios\n  open(newunit=unit, file='page.html', status='old', action='read', iostat=ios)\n  if (ios == 0) then\n     read(unit, '(A)', iostat=ios) line\n     print '(A,A)', '响应首行: ', trim(line)\n     close(unit)\n  else\n     print '(A)', '未获取到响应（离线环境属正常）'\n  end if\n  ! 也可用 iso_c_binding 绑定 libcurl/POSIX socket 实现原生 HTTP\nend program http_demo",
    "et": "❌ 常见错误",
    "ec": "不检查 execute_command_line 的退出码就直接读取响应文件，网络超时或 DNS 失败时读到的是空文件；另外 URL 含 & 或空格却没有加引号，会被 shell 解释成多个命令参数。",
    "q": [
      {
        "q": "execute_command_line 用哪个参数获取外部命令的退出码？",
        "a": "exitstat=整数变量"
      }
    ]
  },
  {
    "id": 30,
    "t": "安全编程",
    "p": [
      "定长字符赋值会静默截断超长输入，接收外部数据前应检查 len_trim 并拒绝超限内容",
      "数组下标默认不做边界检查，编译时加 -fcheck=bounds 或 -fcheck=all 可在测试期捕获越界访问",
      "打开文件用显式 action 与 status，避免误覆盖；临时文件用唯一名称并及时删除，防止信息泄露",
      "不要把口令、密钥硬编码在源码中；SQL 用绑定参数，输出到终端前过滤控制字符防止转义注入"
    ],
    "c": "program secure\n  implicit none\n  character(len=8) :: user\n  integer :: n, ios\n  user = 'admin123456'          ! 超长赋值被静默截断为 8 字符\n  print '(A,A)', 'user = ', trim(user)\n  call get_command_argument(1, user)\n  if (len_trim(user) == 0) then\n     print '(A)', '错误：用户名不能为空'\n     stop 1\n  end if\n  read(user, '(I10)', iostat=ios) n\n  if (ios /= 0) print '(A)', '提示：用户名不是纯数字'\n  ! 安全要点：固定长度字符赋值会静默截断；打开文件要显式 action\n  ! 编译加 -fcheck=all 捕获越界；敏感信息不要硬编码在源码中\nend program secure",
    "et": "❌ 常见错误",
    "ec": "把用户输入直接 MOVE 进固定长度字段，超长部分被悄悄截断，攻击者可用截断绕过长度校验；读取数字时不用 iostat，非法输入会触发运行时错误并暴露内部信息。",
    "q": [
      {
        "q": "Fortran 中编译期开启数组越界检查的选项是什么？",
        "a": "-fcheck=bounds（或 -fcheck=all 开启全部检查）"
      }
    ]
  },
  {
    "id": 31,
    "t": "项目实战：命令行单词统计工具",
    "p": [
      "command_argument_count() 返回命令行参数个数，get_command_argument(i, buf) 取第 i 个参数",
      "get_command_argument 还有 length 与 status 参数，可先探测长度再分配缓冲区，避免截断",
      "命令行工具应返回有意义的退出码：0 成功、1 用法错误、2 文件错误，便于 shell 脚本判断",
      "参数解析手写即可应对少量选项；复杂场景可引入 M_CLI2 等库，但会增加构建依赖"
    ],
    "c": "program wordcount\n  implicit none\n  integer :: ios, i, words\n  character(len=256) :: path, line; character(len=1) :: ch\n  logical :: inword\n  if (command_argument_count() /= 1) then\n     print '(A)', '用法: wordcount 文件名'\n     stop 1\n  end if\n  call get_command_argument(1, path)\n  open(10, file=trim(path), status='old', action='read', iostat=ios)\n  if (ios /= 0) then; print '(A,A)', '无法打开: ', trim(path); stop 2; end if\n  words = 0; inword = .false.\n  do\n     read(10, '(A)', iostat=ios) line\n     if (ios /= 0) exit\n     do i = 1, len_trim(line)\n        ch = line(i:i)\n        if (ch == ' ') then; inword = .false.\n        else if (.not. inword) then; inword = .true.; words = words + 1\n        end if\n     end do\n  end do\n  close(10); print '(A,I0)', '单词数 = ', words\nend program wordcount",
    "et": "❌ 常见错误",
    "ec": "用 get_command_argument 时假定参数一定存在，用户不传参就访问空字符串；或把 len(path) 当实际长度来 open，文件名后面带着一堆空格导致找不到文件，必须用 trim(path)。",
    "q": [
      {
        "q": "读取第 1 个命令行参数到字符串 path，应调用什么？",
        "a": "call get_command_argument(1, path)"
      }
    ]
  },
  {
    "id": 32,
    "t": "项目实战：CSV 销售数据处理",
    "p": [
      "数据处理流程：读取 → 解析 → 校验 → 计算 → 输出，每一步都检查 iostat，避免脏数据继续传播",
      "解析 CSV 可用 index 找分隔符再分段读取；字段含逗号或引号时应改用成熟的 CSV 库",
      "累加金额用 real64 并注意精度，或用整数分；统计前先判断 n > 0，避免除零",
      "输出报告可写 CSV 供表格软件打开，也可用格式串对齐成文本报表，便于人工核对"
    ],
    "c": "program sales_report\n  implicit none\n  integer :: ios, n, i; real :: amount, total\n  character(len=40) :: rec; character(len=20) :: name\n  open(10, file='sales.csv', status='replace')\n  write(10, '(A)') 'A,120.5', 'B,80.0', 'C,199.5'\n  close(10)\n  open(10, file='sales.csv', status='old')\n  total = 0.0; n = 0\n  do\n     read(10, '(A)', iostat=ios) rec\n     if (ios /= 0) exit\n     i = index(rec, ',')\n     if (i > 1) then\n        name = rec(:i-1)\n        read(rec(i+1:), *, iostat=ios) amount\n        if (ios == 0) then\n           total = total + amount; n = n + 1\n           print '(A,A,F8.2)', trim(name), ' 销售额 ', amount\n        end if\n     end if\n  end do\n  close(10)\n  if (n > 0) print '(A,I0,A,F10.2)', '共 ', n, ' 条，合计 ', total\nend program sales_report",
    "et": "❌ 常见错误",
    "ec": "把整行直接 read 成数字而不管逗号，解析必然失败；或只判断文件打开成功就认为数据合法，遇到空行、缺字段时 amount 保留上一条的值继续累加，结果偏大。",
    "q": [
      {
        "q": "CSV 行中查找逗号位置用哪个内置函数？",
        "a": "index(字符串, ',')，返回首次出现的位置，找不到返回 0"
      }
    ]
  },
  {
    "id": 33,
    "t": "构建、部署与发布",
    "p": [
      "发布前用 -O2 -std=f2018 -Wall -Wextra 完整编译，确保没有警告和未定义行为",
      "fpm build --profile release 生成优化版本，fpm install --prefix 安装到指定目录",
      "容器化部署用多阶段构建：编译阶段带 gfortran，运行阶段只拷贝可执行文件与所需动态库",
      "发布物应包含版本号、SHA256 校验值、README 与许可证；strip 可减小二进制体积"
    ],
    "c": "program release\n  implicit none\n  character(len=32), parameter :: version = '1.0.0'\n  print '(A,A)', 'app 版本 ', version\n  ! 构建：gfortran -O2 -std=f2018 -Wall -Wextra src/main.f90 -o app\n  ! fpm：fpm build --profile release && fpm install --prefix ~/.local\n  ! 容器：多阶段构建，运行镜像只拷贝可执行文件与动态库\n  ! 发布：strip app、生成 SHA256、附带 README 与 LICENSE\nend program release",
    "et": "❌ 常见错误",
    "ec": "在开发机用 -march=native 编译后直接分发，换到不支持该指令集的机器就报非法指令；发布构建应使用保守的目标架构，或明确标注运行环境要求。",
    "q": [
      {
        "q": "用 fpm 安装优化版本到 ~/.local，命令是什么？",
        "a": "fpm install --profile release --prefix ~/.local"
      }
    ]
  },
  {
    "id": 34,
    "t": "最佳实践与代码风格",
    "p": [
      "始终写 implicit none；变量声明集中在程序单元开头，并使用有意义的英文命名",
      "过程参数标注 intent，纯计算函数加 pure；模块默认 private，只 public 必要接口",
      "每行不超过 100 列，缩进统一（常用 3 或 4 个空格），运算符两侧留空格，提升可读性",
      "避免 COMMON、EQUIVALENCE、隐式 DO 等老特性；大数组用 allocatable 而非固定尺寸"
    ],
    "c": "module good_style\n  implicit none\n  private\n  public :: normalize\ncontains\n  pure function normalize(x, lo, hi) result(y)\n    real, intent(in) :: x, lo, hi\n    real :: y\n    y = min(max(x, lo), hi)\n  end function normalize\nend module good_style\n\nprogram style_demo\n  use good_style, only: normalize\n  implicit none\n  print '(A,F4.1)', 'normalize(1.5, 0, 1) = ', normalize(1.5, 0.0, 1.0)\n  ! 规范：implicit none、模块封装、intent 标注、函数保持纯计算\nend program style_demo",
    "et": "❌ 常见错误",
    "ec": "把每个变量都声明成全局模块变量，任何过程都能随意修改，程序状态难以追踪；正确做法是数据局部化，通过参数和返回值传递，模块只导出必要接口。",
    "q": [
      {
        "q": "纯函数应加什么属性，且参数应标注什么？",
        "a": "函数加 pure，参数标注 intent(in)（只读）"
      }
    ]
  },
  {
    "id": 35,
    "t": "总结、学习路线与资源",
    "p": [
      "学习路线：语法基础 → 数组与模块 → 文件与派生类型 → 数值算法 → 并行与 C 互操作",
      "官方资源：fortran-lang.org 教程、gfortran 手册、Fortran 2018 标准文档、fpm 官方文档",
      "实践建议：用 fpm 新建项目，边学边写小工具，并用 test-drive 为关键函数补单元测试",
      "进阶方向：OpenMP/MPI 并行、BLAS/LAPACK 数值库、与 Python 通过 C 接口或 f2py 混合编程"
    ],
    "c": "program roadmap\n  implicit none\n  integer :: stage\n  character(len=24), parameter :: topics(3) = [character(len=24) :: &\n       '数组与模块', '文件与派生类型', '并行与 C 互操作']\n  do stage = 1, 3\n     print '(A,I0,A,A)', '第 ', stage, ' 阶段: ', trim(topics(stage))\n  end do\n  print '(A)', '资源: fortran-lang.org / gfortran 手册 / fpm / test-drive'\nend program roadmap",
    "et": "❌ 常见错误",
    "ec": "学完语法就停在“能编译”层面，不写项目也不读他人代码；Fortran 的数组运算、模块接口和列优先布局只有在实际数值程序中才能体会，建议尽早用 fpm 做一个小项目。",
    "q": [
      {
        "q": "Fortran 包管理与构建工具的名字是什么？",
        "a": "fpm（Fortran Package Manager）"
      }
    ]
  }
];
