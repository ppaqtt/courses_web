window.TUTORIAL_DATA_javascript = [
  {
    "id": 1,
    "t": "JavaScript 简介",
    "p": [
      "JavaScript 是一种脚本语言，用于为网页添加交互性",
      "1995年由 Brendan Eich 在 Netscape 公司创建",
      "JavaScript 可以在浏览器和服务器端（Node.js）运行",
      "是 Web 开发三大核心技术之一（HTML、CSS、JavaScript）",
      "支持面向对象、函数式和事件驱动编程"
    ],
    "c": "// 第一个 JavaScript 程序\nconsole.log('Hello, JavaScript!');\n\n// 在网页中显示消息\nalert('欢迎学习 JavaScript！');\n\n// 向 HTML 页面写入内容\ndocument.write('<h1>Hello, World!</h1>');",
    "et": "❌ 常见错误：拼写错误",
    "ec": "将 console.log 拼写成 console.Log 或 Console.log，JavaScript 是大小写敏感的语言。",
    "q": [
      "使用 console.log() 输出你的名字",
      "使用 alert() 显示一条欢迎消息",
      "使用 document.write() 在页面上显示当前日期"
    ]
  },
  {
    "id": 2,
    "t": "变量与数据类型",
    "p": [
      "变量用于存储数据值，使用 var、let、const 声明",
      "let 和 const 是 ES6 引入的块级作用域变量",
      "const 声明的变量不能重新赋值",
      "基本数据类型：string、number、boolean、null、undefined、symbol",
      "typeof 运算符用于检测数据类型"
    ],
    "c": "// 使用 var 声明变量（函数作用域）\nvar name = '张三';\nvar age = 25;\n\n// 使用 let 声明变量（块级作用域）\nlet isStudent = true;\nlet score = 95.5;\n\n// 使用 const 声明常量\nconst PI = 3.14159;\nconst COLOR = '#667eea';\n\n// 检测数据类型\nconsole.log(typeof name);    // string\nconsole.log(typeof age);     // number\nconsole.log(typeof isStudent); // boolean",
    "et": "❌ 常见错误：重复声明变量",
    "ec": "使用 let 或 const 重复声明同一变量会抛出错误。应该避免在同一作用域内重复声明变量。",
    "q": [
      "声明一个变量存储你的年龄，并输出其类型",
      "声明一个常量存储圆周率",
      "声明一个变量存储你的邮箱，然后修改它的值"
    ]
  },
  {
    "id": 3,
    "t": "运算符",
    "p": [
      "算术运算符：+、-、*、/、%、++、--",
      "赋值运算符：=、+=、-=、*=、/=",
      "比较运算符：==、===、!=、!==、>、<、>=、<=",
      "逻辑运算符：&&、||、!",
      "三元运算符：条件 ? 表达式1 : 表达式2"
    ],
    "c": "// 算术运算符\nlet a = 10;\nlet b = 3;\nconsole.log(a + b);   // 13\nconsole.log(a % b);   // 1\nconsole.log(a++);     // 10（后自增）\nconsole.log(++a);     // 12（前自增）\n\n// 比较运算符\nconsole.log(5 == '5');    // true（宽松相等）\nconsole.log(5 === '5');   // false（严格相等）\n\n// 逻辑运算符\nlet x = true;\nlet y = false;\nconsole.log(x && y);  // false\nconsole.log(x || y);  // true\nconsole.log(!x);      // false\n\n// 三元运算符\nlet score = 85;\nlet result = score >= 60 ? '及格' : '不及格';\nconsole.log(result);  // 及格",
    "et": "❌ 常见错误：混淆 == 和 ===",
    "ec": "使用 == 会进行类型转换，可能导致意外结果。推荐使用 === 进行严格相等比较。",
    "q": [
      "计算两个数的和、差、积、商",
      "使用三元运算符判断一个数是正数还是负数",
      "使用逻辑运算符判断年份是否为闰年"
    ]
  },
  {
    "id": 4,
    "t": "流程控制 - if-else",
    "p": [
      "if 语句用于条件判断",
      "else 语句处理条件不满足的情况",
      "else if 用于多个条件判断",
      "条件表达式返回布尔值（true/false）",
      "代码块使用花括号 {} 包裹"
    ],
    "c": "// 简单 if 语句\nlet age = 18;\nif (age >= 18) {\n    console.log('成年人');\n}\n\n// if-else 语句\nlet score = 75;\nif (score >= 60) {\n    console.log('及格');\n} else {\n    console.log('不及格');\n}\n\n// else if 多条件判断\nlet grade = 'B';\nif (grade === 'A') {\n    console.log('优秀');\n} else if (grade === 'B') {\n    console.log('良好');\n} else if (grade === 'C') {\n    console.log('中等');\n} else {\n    console.log('需努力');\n}",
    "et": "❌ 常见错误：使用 = 代替 ==",
    "ec": "在条件判断中使用赋值运算符 = 而不是比较运算符 ==，这会导致条件永远为真（除非赋值为 falsy 值）。",
    "q": [
      "判断一个数是否为偶数",
      "根据分数输出对应的等级（90以上A，80-89B，70-79C，60-69D，60以下F）",
      "判断年份是否为闰年"
    ]
  },
  {
    "id": 5,
    "t": "流程控制 - switch",
    "p": [
      "switch 语句用于多条件分支判断",
      "每个 case 对应一个分支",
      "break 语句用于跳出 switch",
      "default 处理未匹配的情况",
      "switch 使用严格相等（===）比较"
    ],
    "c": "// switch 基本用法\nlet day = 3;\nswitch (day) {\n    case 1:\n        console.log('星期一');\n        break;\n    case 2:\n        console.log('星期二');\n        break;\n    case 3:\n        console.log('星期三');\n        break;\n    default:\n        console.log('其他日期');\n}\n\n// 多个 case 共享代码块\nlet month = 2;\nswitch (month) {\n    case 1:\n    case 3:\n    case 5:\n    case 7:\n    case 8:\n    case 10:\n    case 12:\n        console.log('31天');\n        break;\n    case 4:\n    case 6:\n    case 9:\n    case 11:\n        console.log('30天');\n        break;\n    case 2:\n        console.log('28或29天');\n        break;\n}",
    "et": "❌ 常见错误：忘记 break 语句",
    "ec": "如果忘记在 case 末尾添加 break，程序会继续执行下一个 case，这称为\"贯穿\"现象。",
    "q": [
      "使用 switch 根据月份输出季节",
      "使用 switch 根据成绩等级输出评语",
      "使用 switch 判断星期几并输出对应的中文名称"
    ]
  },
  {
    "id": 6,
    "t": "循环 - for",
    "p": [
      "for 循环由初始化、条件、更新三部分组成",
      "语法：for(初始化; 条件; 更新) { 代码块 }",
      "break 跳出循环",
      "continue 跳过当前迭代",
      "循环变量通常用 i、j、k 命名"
    ],
    "c": "// 基本 for 循环\nfor (let i = 0; i < 5; i++) {\n    console.log('计数: ' + i);\n}\n\n// 遍历数组\nlet fruits = ['苹果', '香蕉', '橙子'];\nfor (let i = 0; i < fruits.length; i++) {\n    console.log(fruits[i]);\n}\n\n// 使用 break 跳出循环\nfor (let i = 0; i < 10; i++) {\n    if (i === 5) {\n        break;  // 当 i 等于 5 时跳出\n    }\n    console.log(i);\n}\n\n// 使用 continue 跳过迭代\nfor (let i = 0; i < 10; i++) {\n    if (i % 2 === 0) {\n        continue;  // 跳过偶数\n    }\n    console.log(i);\n}",
    "et": "❌ 常见错误：无限循环",
    "ec": "忘记更新循环变量或条件永远为真会导致无限循环，使浏览器卡死。",
    "q": [
      "使用 for 循环输出 1 到 100 的所有数",
      "计算 1 到 100 的和",
      "输出 100 以内的所有质数"
    ]
  },
  {
    "id": 7,
    "t": "循环 - while 与 do-while",
    "p": [
      "while 循环：先判断条件，再执行代码",
      "do-while 循环：先执行代码，再判断条件",
      "do-while 至少执行一次",
      "while 可能一次都不执行",
      "同样支持 break 和 continue"
    ],
    "c": "// while 循环\nlet count = 0;\nwhile (count < 5) {\n    console.log('计数: ' + count);\n    count++;\n}\n\n// do-while 循环\nlet num = 0;\ndo {\n    console.log('数字: ' + num);\n    num++;\n} while (num < 5);\n\n// 求阶乘\nlet n = 5;\nlet factorial = 1;\nwhile (n > 0) {\n    factorial *= n;\n    n--;\n}\nconsole.log('5的阶乘: ' + factorial);\n\n// 猜数字游戏\nlet target = 7;\nlet guess;\ndo {\n    guess = parseInt(prompt('猜一个1-10的数字'));\n} while (guess !== target);\nconsole.log('猜对了！');",
    "et": "❌ 常见错误：忘记更新循环变量",
    "ec": "在 while 或 do-while 循环中忘记更新控制变量会导致无限循环。",
    "q": [
      "使用 while 循环计算 1 到 50 的和",
      "使用 do-while 循环输出 20 到 1 的倒序",
      "使用 while 循环实现斐波那契数列前20项"
    ]
  },
  {
    "id": 8,
    "t": "函数基础",
    "p": [
      "函数是可重复使用的代码块",
      "使用 function 关键字定义函数",
      "函数可以有参数和返回值",
      "函数调用时传递实参",
      "函数可以没有参数和返回值"
    ],
    "c": "// 无参数无返回值函数\nfunction greet() {\n    console.log('Hello!');\n}\ngreet();\n\n// 有参数函数\nfunction sayHello(name) {\n    console.log('Hello, ' + name + '!');\n}\nsayHello('张三');\n\n// 有返回值函数\nfunction add(a, b) {\n    return a + b;\n}\nlet result = add(3, 5);\nconsole.log(result);  // 8\n\n// 多参数函数\nfunction calculate(a, b, operator) {\n    switch(operator) {\n        case '+': return a + b;\n        case '-': return a - b;\n        case '*': return a * b;\n        case '/': return a / b;\n        default: return '无效运算符';\n    }\n}\nconsole.log(calculate(10, 2, '*'));  // 20",
    "et": "❌ 常见错误：函数名拼写错误",
    "ec": "调用函数时拼写错误会导致\"is not defined\"错误。确保函数名和调用时一致。",
    "q": [
      "定义一个函数计算圆的面积",
      "定义一个函数判断一个数是否为质数",
      "定义一个函数将华氏温度转换为摄氏温度"
    ]
  },
  {
    "id": 9,
    "t": "函数参数与返回值",
    "p": [
      "参数分为形参和实参",
      "ES6 支持默认参数值",
      "使用 arguments 对象访问所有参数",
      "return 语句可以返回任意类型的值",
      "没有 return 的函数返回 undefined"
    ],
    "c": "// 默认参数\nfunction greet(name = 'Guest') {\n    console.log('Hello, ' + name);\n}\ngreet();          // Hello, Guest\ngreet('李四');    // Hello, 李四\n\n// 使用 arguments 对象\nfunction sum() {\n    let total = 0;\n    for (let i = 0; i < arguments.length; i++) {\n        total += arguments[i];\n    }\n    return total;\n}\nconsole.log(sum(1, 2, 3, 4));  // 10\n\n// 返回对象\nfunction createUser(name, age) {\n    return {\n        name: name,\n        age: age,\n        createdAt: new Date()\n    };\n}\nlet user = createUser('王五', 30);\nconsole.log(user);\n\n// 返回函数\nfunction createMultiplier(n) {\n    return function(x) {\n        return x * n;\n    };\n}\nlet double = createMultiplier(2);\nconsole.log(double(5));  // 10",
    "et": "❌ 常见错误：参数数量不匹配",
    "ec": "传递的参数少于函数定义的参数时，多余的参数为 undefined。传递过多参数则会被忽略。",
    "q": [
      "定义一个函数，计算任意数量数字的平均值",
      "定义一个函数，返回数组中的最大值和最小值",
      "定义一个函数，接收姓名和年龄，返回问候语"
    ]
  },
  {
    "id": 10,
    "t": "作用域",
    "p": [
      "全局作用域：在函数外部声明的变量",
      "局部作用域：在函数内部声明的变量",
      "块级作用域：ES6 的 let/const 声明",
      "变量提升：var 声明的变量会提升到作用域顶部",
      "作用域链：内部函数可以访问外部函数的变量"
    ],
    "c": "// 全局变量\nlet globalVar = '全局';\n\nfunction outer() {\n    // 函数作用域变量\n    let outerVar = '外部';\n    \n    function inner() {\n        // 内部函数可以访问外部变量\n        let innerVar = '内部';\n        console.log(globalVar);   // 全局\n        console.log(outerVar);    // 外部\n        console.log(innerVar);    // 内部\n    }\n    \n    inner();\n    // console.log(innerVar); // 错误：无法访问内部变量\n}\n\nouter();\n\n// 块级作用域\nif (true) {\n    let blockVar = '块级';\n    console.log(blockVar);  // 块级\n}\n// console.log(blockVar); // 错误：let 声明的变量只在块内有效\n\n// 变量提升\nconsole.log(hoistedVar);  // undefined（变量被提升，但值未初始化）\nvar hoistedVar = '提升';",
    "et": "❌ 常见错误：误用全局变量",
    "ec": "在函数内部未使用 var/let/const 声明的变量会成为全局变量，这可能导致意外的副作用。",
    "q": [
      "解释全局作用域和局部作用域的区别",
      "为什么使用 let 比 var 更好？",
      "编写代码演示变量提升现象"
    ]
  },
  {
    "id": 11,
    "t": "数组",
    "p": [
      "数组是有序的数据集合",
      "使用 [] 创建数组",
      "通过索引访问数组元素（从0开始）",
      "length 属性获取数组长度",
      "常用方法：push、pop、shift、unshift、slice、splice"
    ],
    "c": "// 创建数组\nlet fruits = ['苹果', '香蕉', '橙子'];\nlet numbers = [1, 2, 3, 4, 5];\nlet mixed = [1, 'hello', true, null];\n\n// 访问数组元素\nconsole.log(fruits[0]);  // 苹果\nconsole.log(fruits[2]);  // 橙子\n\n// 修改数组元素\nfruits[1] = '葡萄';\nconsole.log(fruits);  // ['苹果', '葡萄', '橙子']\n\n// 数组长度\nconsole.log(fruits.length);  // 3\n\n// 添加元素\nfruits.push('西瓜');      // 末尾添加\nfruits.unshift('草莓');   // 开头添加\nconsole.log(fruits);\n\n// 删除元素\nfruits.pop();       // 删除末尾\nfruits.shift();     // 删除开头\nconsole.log(fruits);\n\n// 切片\nlet sliced = fruits.slice(1, 3);\nconsole.log(sliced);  // ['葡萄', '橙子']\n\n// 拼接\nfruits.splice(1, 0, '芒果', '菠萝');\nconsole.log(fruits);",
    "et": "❌ 常见错误：数组索引越界",
    "ec": "访问不存在的数组索引会返回 undefined，而不是报错。注意数组索引从0开始。",
    "q": [
      "创建一个包含5个元素的数组，然后在末尾添加2个元素",
      "反转一个数组（不使用 reverse 方法）",
      "找出数组中的最大值"
    ]
  },
  {
    "id": 12,
    "t": "数组方法",
    "p": [
      "forEach：遍历数组",
      "map：转换数组元素",
      "filter：过滤数组元素",
      "reduce：累加数组元素",
      "find/findIndex：查找元素",
      "sort：排序数组"
    ],
    "c": "let numbers = [1, 2, 3, 4, 5];\n\n// forEach 遍历\nnumbers.forEach(function(num, index) {\n    console.log(index + ': ' + num);\n});\n\n// map 转换\nlet doubled = numbers.map(function(num) {\n    return num * 2;\n});\nconsole.log(doubled);  // [2, 4, 6, 8, 10]\n\n// filter 过滤\nlet evens = numbers.filter(function(num) {\n    return num % 2 === 0;\n});\nconsole.log(evens);  // [2, 4]\n\n// reduce 累加\nlet sum = numbers.reduce(function(acc, num) {\n    return acc + num;\n}, 0);\nconsole.log(sum);  // 15\n\n// find 查找\nlet found = numbers.find(function(num) {\n    return num > 3;\n});\nconsole.log(found);  // 4\n\n// sort 排序\nlet words = ['banana', 'apple', 'cherry'];\nwords.sort();\nconsole.log(words);  // ['apple', 'banana', 'cherry']",
    "et": "❌ 常见错误：sort 方法默认按字符串排序",
    "ec": "数组的 sort() 方法默认将元素转换为字符串进行比较，数字排序需要提供比较函数。",
    "q": [
      "使用 map 将数组中的每个元素平方",
      "使用 filter 过滤出大于 10 的数字",
      "使用 reduce 计算数组中所有元素的乘积"
    ]
  },
  {
    "id": 13,
    "t": "对象",
    "p": [
      "对象是键值对的集合",
      "使用 {} 创建对象",
      "通过点号或方括号访问属性",
      "可以添加、修改、删除属性",
      "for...in 遍历对象属性"
    ],
    "c": "// 创建对象\nlet person = {\n    name: '张三',\n    age: 25,\n    isStudent: true,\n    hobbies: ['阅读', '编程']\n};\n\n// 访问属性\nconsole.log(person.name);           // 张三\nconsole.log(person['age']);         // 25\nconsole.log(person.hobbies[0]);     // 阅读\n\n// 修改属性\nperson.age = 26;\nperson['isStudent'] = false;\n\n// 添加属性\nperson.email = 'zhangsan@example.com';\nperson.address = {\n    city: '北京',\n    street: '朝阳区'\n};\n\n// 删除属性\ndelete person.isStudent;\n\n// 遍历对象\nfor (let key in person) {\n    console.log(key + ': ' + person[key]);\n}\n\n// 检查属性是否存在\nconsole.log('name' in person);      // true\nconsole.log('phone' in person);     // false",
    "et": "❌ 常见错误：访问未定义的属性",
    "ec": "访问对象不存在的属性会返回 undefined，而不是报错。使用 in 运算符检查属性是否存在。",
    "q": [
      "创建一个表示书籍的对象，包含书名、作者、价格",
      "遍历对象并输出所有键值对",
      "给对象添加一个方法，用于输出书籍信息"
    ]
  },
  {
    "id": 14,
    "t": "字符串方法",
    "p": [
      "length：获取字符串长度",
      "charAt/charCodeAt：获取字符",
      "indexOf/lastIndexOf：查找字符位置",
      "slice/substring：截取字符串",
      "toUpperCase/toLowerCase：转换大小写",
      "trim：去除首尾空格",
      "split：分割字符串",
      "replace：替换字符串"
    ],
    "c": "let str = '  Hello, JavaScript!  ';\n\n// 字符串长度\nconsole.log(str.length);  // 24\n\n// 获取字符\nconsole.log(str.charAt(2));    // H\nconsole.log(str.charCodeAt(2)); // 72\n\n// 查找位置\nconsole.log(str.indexOf('o'));    // 4\nconsole.log(str.lastIndexOf('a')); // 14\n\n// 截取字符串\nconsole.log(str.slice(2, 7));     // Hello\nconsole.log(str.substring(2, 7)); // Hello\n\n// 转换大小写\nconsole.log(str.toUpperCase());   // HELLO, JAVASCRIPT!\nconsole.log(str.toLowerCase());   // hello, javascript!\n\n// 去除空格\nconsole.log(str.trim());          // Hello, JavaScript!\n\n// 分割字符串\nlet words = str.trim().split(' ');\nconsole.log(words);  // ['Hello,', 'JavaScript!']\n\n// 替换\nconsole.log(str.replace('JavaScript', 'World'));\n\n// 模板字符串\nlet name = '张三';\nlet greeting = `你好，${name}！今天是${new Date().getFullYear()}年`;\nconsole.log(greeting);",
    "et": "❌ 常见错误：字符串是不可变的",
    "ec": "JavaScript 中的字符串是不可变的，所有字符串方法都返回新字符串，不会修改原字符串。",
    "q": [
      "统计字符串中某个字符出现的次数",
      "反转一个字符串",
      "检查字符串是否为回文"
    ]
  },
  {
    "id": 15,
    "t": "日期对象",
    "p": [
      "使用 new Date() 创建日期对象",
      "getFullYear：获取年份",
      "getMonth：获取月份（0-11）",
      "getDate：获取日期（1-31）",
      "getDay：获取星期（0-6）",
      "getTime：获取时间戳",
      "日期格式化"
    ],
    "c": "// 创建日期对象\nlet now = new Date();\nconsole.log(now);\n\n// 创建指定日期\nlet date1 = new Date('2024-01-15');\nlet date2 = new Date(2024, 0, 15, 10, 30, 0);\n\n// 获取日期信息\nconsole.log(now.getFullYear());   // 年份\nconsole.log(now.getMonth() + 1);  // 月份（加1）\nconsole.log(now.getDate());       // 日期\nconsole.log(now.getDay());        // 星期\nconsole.log(now.getHours());      // 小时\nconsole.log(now.getMinutes());    // 分钟\nconsole.log(now.getSeconds());    // 秒\n\n// 获取时间戳\nconsole.log(now.getTime());\n\n// 日期格式化函数\nfunction formatDate(date) {\n    let year = date.getFullYear();\n    let month = String(date.getMonth() + 1).padStart(2, '0');\n    let day = String(date.getDate()).padStart(2, '0');\n    return `${year}-${month}-${day}`;\n}\nconsole.log(formatDate(now));\n\n// 日期计算\nlet tomorrow = new Date();\ntomorrow.setDate(tomorrow.getDate() + 1);\nconsole.log('明天:', formatDate(tomorrow));",
    "et": "❌ 常见错误：月份从0开始",
    "ec": "JavaScript 的 getMonth() 方法返回 0-11，而不是 1-12。获取正确月份需要加1。",
    "q": [
      "编写一个函数格式化日期为 YYYY-MM-DD HH:mm:ss",
      "计算两个日期之间相差的天数",
      "判断今天是星期几并输出中文名称"
    ]
  },
  {
    "id": 16,
    "t": "数学对象",
    "p": [
      "Math 是内置对象，无需创建实例",
      "Math.PI：圆周率",
      "Math.abs：绝对值",
      "Math.round/floor/ceil：四舍五入",
      "Math.max/min：最大最小值",
      "Math.random：随机数",
      "Math.pow：幂运算"
    ],
    "c": "// 常量\nconsole.log(Math.PI);      // 3.141592653589793\nconsole.log(Math.E);       // 2.718281828459045\n\n// 绝对值\nconsole.log(Math.abs(-5)); // 5\n\n// 四舍五入\nconsole.log(Math.round(3.6));  // 4\nconsole.log(Math.floor(3.9));  // 3\nconsole.log(Math.ceil(3.1));   // 4\n\n// 最大最小值\nconsole.log(Math.max(1, 3, 5, 2));  // 5\nconsole.log(Math.min(1, 3, 5, 2));  // 1\n\n// 幂运算和开方\nconsole.log(Math.pow(2, 3));  // 8\nconsole.log(Math.sqrt(16));   // 4\n\n// 随机数\nconsole.log(Math.random());         // 0-1之间的随机数\nconsole.log(Math.floor(Math.random() * 10));  // 0-9的整数\n\n// 三角函数\nconsole.log(Math.sin(Math.PI / 2));  // 1\nconsole.log(Math.cos(Math.PI));      // -1\n\n// 生成指定范围的随机整数\nfunction randomInt(min, max) {\n    return Math.floor(Math.random() * (max - min + 1)) + min;\n}\nconsole.log(randomInt(1, 100));",
    "et": "❌ 常见错误：忘记 Math 对象前缀",
    "ec": "Math 的方法需要使用 Math.xxx() 的形式调用，不能直接调用。",
    "q": [
      "计算圆的周长和面积",
      "生成1-100之间的随机整数",
      "计算数组中所有元素的平均值"
    ]
  },
  {
    "id": 17,
    "t": "类型转换",
    "p": [
      "显式转换：Number()、String()、Boolean()",
      "隐式转换：自动发生的类型转换",
      "parseInt/parseFloat：解析数字",
      "toString()：转换为字符串",
      "+ 运算符的转换规则"
    ],
    "c": "// 显式转换为数字\nconsole.log(Number('123'));      // 123\nconsole.log(Number('abc'));      // NaN\nconsole.log(Number(true));       // 1\nconsole.log(Number(false));      // 0\nconsole.log(Number(null));       // 0\nconsole.log(Number(undefined));  // NaN\n\n// 显式转换为字符串\nconsole.log(String(123));        // '123'\nconsole.log(String(true));       // 'true'\nconsole.log(String(null));       // 'null'\n\n// 显式转换为布尔值\nconsole.log(Boolean(0));         // false\nconsole.log(Boolean(''));        // false\nconsole.log(Boolean(null));      // false\nconsole.log(Boolean(undefined)); // false\nconsole.log(Boolean(1));         // true\nconsole.log(Boolean('hello'));   // true\n\n// 解析数字\nconsole.log(parseInt('123abc'));  // 123\nconsole.log(parseFloat('3.14abc')); // 3.14\n\n// toString 方法\nconsole.log((123).toString());    // '123'\nconsole.log((true).toString());   // 'true'\n\n// 隐式转换\nconsole.log('5' + 3);   // '53'（字符串拼接）\nconsole.log('5' - 3);   // 2（数字相减）\nconsole.log('abc' - 1); // NaN",
    "et": "❌ 常见错误：字符串拼接与数学运算混淆",
    "ec": "使用 + 运算符时，如果其中一个操作数是字符串，会进行字符串拼接而不是数学加法。",
    "q": [
      "将字符串 '100' 转换为数字并加 50",
      "判断变量是否为 falsy 值",
      "解释为什么 '5' + 3 结果是 '53'"
    ]
  },
  {
    "id": 18,
    "t": "错误处理",
    "p": [
      "try...catch：捕获和处理异常",
      "finally：无论是否异常都会执行",
      "throw：主动抛出异常",
      "Error 对象：包含错误信息",
      "常见错误类型：SyntaxError、ReferenceError、TypeError"
    ],
    "c": "// try...catch 基本用法\ntry {\n    let result = riskyOperation();\n    console.log(result);\n} catch (error) {\n    console.error('发生错误:', error.message);\n}\n\n// try...catch...finally\ntry {\n    let data = JSON.parse('invalid json');\n} catch (error) {\n    console.error('解析失败:', error);\n} finally {\n    console.log('无论如何都会执行');\n}\n\n// 主动抛出异常\nfunction divide(a, b) {\n    if (b === 0) {\n        throw new Error('除数不能为零');\n    }\n    return a / b;\n}\n\ntry {\n    console.log(divide(10, 0));\n} catch (error) {\n    console.error(error.message);\n}\n\n// 自定义错误类型\nclass ValidationError extends Error {\n    constructor(message) {\n        super(message);\n        this.name = 'ValidationError';\n    }\n}\n\nfunction validateUser(user) {\n    if (!user.name) {\n        throw new ValidationError('用户名不能为空');\n    }\n}\n\ntry {\n    validateUser({});\n} catch (error) {\n    if (error instanceof ValidationError) {\n        console.error('验证失败:', error.message);\n    }\n}",
    "et": "❌ 常见错误：忽略错误处理",
    "ec": "不使用 try...catch 处理可能出错的代码，会导致程序崩溃。应该始终处理可能的异常。",
    "q": [
      "编写一个函数，使用 try...catch 处理 JSON 解析错误",
      "创建一个自定义错误类型并使用它",
      "编写一个安全的除法函数，处理除数为零的情况"
    ]
  },
  {
    "id": 19,
    "t": "事件处理",
    "p": [
      "事件是用户与网页交互产生的动作",
      "常见事件：click、mouseover、keydown、submit",
      "使用 addEventListener 添加事件监听",
      "事件对象：包含事件相关信息",
      "事件冒泡和事件捕获",
      "preventDefault：阻止默认行为",
      "stopPropagation：阻止事件传播"
    ],
    "c": "// 获取元素\nlet btn = document.getElementById('myBtn');\nlet input = document.getElementById('myInput');\n\n// 添加点击事件\nbtn.addEventListener('click', function(event) {\n    console.log('按钮被点击');\n    console.log('事件类型:', event.type);\n    console.log('点击位置:', event.clientX, event.clientY);\n});\n\n// 添加鼠标悬停事件\nbtn.addEventListener('mouseover', function() {\n    btn.style.backgroundColor = '#5a6fd6';\n});\n\nbtn.addEventListener('mouseout', function() {\n    btn.style.backgroundColor = '#667eea';\n});\n\n// 键盘事件\ninput.addEventListener('keydown', function(event) {\n    if (event.key === 'Enter') {\n        console.log('输入内容:', input.value);\n    }\n});\n\n// 表单提交事件\nlet form = document.getElementById('myForm');\nform.addEventListener('submit', function(event) {\n    event.preventDefault(); // 阻止默认提交行为\n    console.log('表单提交');\n});\n\n// 事件委托\ndocument.addEventListener('click', function(event) {\n    if (event.target.classList.contains('delete-btn')) {\n        event.target.parentElement.remove();\n    }\n});",
    "et": "❌ 常见错误：忘记阻止默认行为",
    "ec": "表单提交、链接点击等默认行为会导致页面刷新，需要使用 preventDefault() 阻止。",
    "q": [
      "创建一个按钮，点击后显示当前时间",
      "实现一个图片画廊，点击缩略图显示大图",
      "实现表单验证，提交前检查必填字段"
    ]
  },
  {
    "id": 20,
    "t": "DOM 操作",
    "p": [
      "DOM：文档对象模型",
      "getElementById：通过ID获取元素",
      "getElementsByClassName：通过类名获取元素",
      "querySelector/querySelectorAll：CSS选择器",
      "innerHTML/innerText：修改内容",
      "setAttribute/getAttribute：操作属性",
      "createElement/appendChild：创建元素"
    ],
    "c": "// 获取元素\nlet byId = document.getElementById('myId');\nlet byClass = document.getElementsByClassName('myClass');\nlet byTag = document.getElementsByTagName('div');\n\n// CSS选择器\nlet first = document.querySelector('.myClass');\nlet all = document.querySelectorAll('.myClass');\n\n// 修改内容\nbyId.innerHTML = '<p>新内容</p>';\nbyId.innerText = '纯文本内容';\n\n// 修改样式\nbyId.style.color = 'red';\nbyId.style.fontSize = '20px';\n\n// 修改类名\nbyId.classList.add('active');\nbyId.classList.remove('active');\nbyId.classList.toggle('active');\n\n// 操作属性\nbyId.setAttribute('data-id', '123');\nconsole.log(byId.getAttribute('data-id'));\n\n// 创建元素\nlet newDiv = document.createElement('div');\nnewDiv.textContent = '新元素';\nbyId.appendChild(newDiv);\n\n// 删除元素\nnewDiv.remove();",
    "et": "❌ 常见错误：在DOM加载前操作元素",
    "ec": "如果JavaScript代码在DOM加载前执行，getElementById会返回null。需要将代码放在DOMContentLoaded事件中。",
    "q": [
      "创建一个列表，动态添加10个项目",
      "实现一个简单的待办事项列表",
      "创建一个按钮，点击后切换元素的显示/隐藏"
    ]
  },
  {
    "id": 21,
    "t": "定时器",
    "p": [
      "setTimeout：延迟执行一次",
      "setInterval：周期性执行",
      "clearTimeout/clearInterval：清除定时器",
      "定时器返回ID用于清除",
      "this在定时器中的指向问题"
    ],
    "c": "// setTimeout：延迟执行\nlet timeoutId = setTimeout(function() {\n    console.log('2秒后执行');\n}, 2000);\n\n// 清除 setTimeout\nclearTimeout(timeoutId);\n\n// setInterval：周期性执行\nlet count = 0;\nlet intervalId = setInterval(function() {\n    count++;\n    console.log('第' + count + '次执行');\n    if (count >= 5) {\n        clearInterval(intervalId);\n        console.log('停止执行');\n    }\n}, 1000);\n\n// 使用箭头函数保持 this 指向\nlet person = {\n    name: '张三',\n    greet: function() {\n        setTimeout(() => {\n            console.log('你好，' + this.name);\n        }, 1000);\n    }\n};\nperson.greet();\n\n// 倒计时示例\nfunction countdown(seconds) {\n    let timer = setInterval(function() {\n        seconds--;\n        console.log(seconds);\n        if (seconds <= 0) {\n            clearInterval(timer);\n            console.log('时间到！');\n        }\n    }, 1000);\n}\ncountdown(5);",
    "et": "❌ 常见错误：忘记清除定时器",
    "ec": "不清除不再需要的setInterval会导致内存泄漏和性能问题。",
    "q": [
      "实现一个3秒倒计时",
      "实现一个数字时钟，每秒更新一次",
      "创建一个自动轮播图"
    ]
  },
  {
    "id": 22,
    "t": "JSON",
    "p": [
      "JSON：JavaScript对象表示法",
      "JSON.stringify：对象转JSON字符串",
      "JSON.parse：JSON字符串转对象",
      "JSON格式：键必须用双引号",
      "不支持函数、日期对象等"
    ],
    "c": "// 对象转JSON字符串\nlet person = {\n    name: '张三',\n    age: 25,\n    hobbies: ['阅读', '编程']\n};\n\nlet jsonStr = JSON.stringify(person);\nconsole.log(jsonStr);\n// 输出: {\"name\":\"张三\",\"age\":25,\"hobbies\":[\"阅读\",\"编程\"]}\n\n// JSON字符串转对象\nlet jsonString = '{\"name\":\"李四\",\"age\":30}';\nlet obj = JSON.parse(jsonString);\nconsole.log(obj.name);  // 李四\n\n// 格式化输出\nlet prettyJson = JSON.stringify(person, null, 2);\nconsole.log(prettyJson);\n\n// 自定义序列化\nlet user = {\n    name: '王五',\n    password: 'secret',\n    createdAt: new Date()\n};\n\nlet safeJson = JSON.stringify(user, function(key, value) {\n    if (key === 'password') return undefined;\n    if (value instanceof Date) return value.toISOString();\n    return value;\n});\nconsole.log(safeJson);\n\n// 解析时处理日期\nlet data = JSON.parse('{\"date\":\"2024-01-15T10:30:00.000Z\"}', function(key, value) {\n    if (key === 'date') return new Date(value);\n    return value;\n});\nconsole.log(data.date);",
    "et": "❌ 常见错误：JSON格式错误",
    "ec": "JSON字符串中键必须使用双引号，不能使用单引号或无引号。解析格式错误的JSON会抛出异常。",
    "q": [
      "创建一个对象并序列化为JSON字符串",
      "解析JSON数据并显示在页面上",
      "实现一个简单的本地存储功能"
    ]
  },
  {
    "id": 23,
    "t": "本地存储",
    "p": [
      "localStorage：永久存储",
      "sessionStorage：会话存储",
      "setItem：存储数据",
      "getItem：获取数据",
      "removeItem：删除数据",
      "clear：清空所有数据",
      "只能存储字符串"
    ],
    "c": "// localStorage 存储字符串\nlocalStorage.setItem('username', '张三');\nlocalStorage.setItem('age', '25');\n\n// 获取数据\nlet username = localStorage.getItem('username');\nconsole.log(username);\n\n// 存储对象（需要先转为JSON）\nlet user = { name: '李四', age: 30 };\nlocalStorage.setItem('user', JSON.stringify(user));\n\n// 获取对象\nlet savedUser = JSON.parse(localStorage.getItem('user'));\nconsole.log(savedUser.name);\n\n// 删除数据\nlocalStorage.removeItem('age');\n\n// 清空所有数据\n// localStorage.clear();\n\n// 遍历所有存储项\nfor (let i = 0; i < localStorage.length; i++) {\n    let key = localStorage.key(i);\n    console.log(key + ': ' + localStorage.getItem(key));\n}\n\n// sessionStorage（页面关闭后清除）\nsessionStorage.setItem('sessionKey', 'sessionValue');\n\n// 监听存储变化\nwindow.addEventListener('storage', function(event) {\n    console.log('存储变化:', event.key, event.newValue);\n});\n\n// 待办事项存储示例\nfunction saveTodos(todos) {\n    localStorage.setItem('todos', JSON.stringify(todos));\n}\n\nfunction getTodos() {\n    let todos = localStorage.getItem('todos');\n    return todos ? JSON.parse(todos) : [];\n}",
    "et": "❌ 常见错误：直接存储对象",
    "ec": "localStorage只能存储字符串，存储对象前必须使用JSON.stringify转换，读取时使用JSON.parse转换回来。",
    "q": [
      "实现一个待办事项列表，使用localStorage保存",
      "创建一个用户设置页面，保存用户偏好",
      "实现一个浏览历史记录功能"
    ]
  },
  {
    "id": 24,
    "t": "异步编程基础",
    "p": [
      "同步代码：按顺序执行",
      "异步代码：不阻塞后续执行",
      "回调函数：异步操作完成后执行",
      "事件循环：JavaScript的执行机制",
      "宏任务和微任务"
    ],
    "c": "// 同步代码\nconsole.log('1');\nconsole.log('2');\nconsole.log('3');\n\n// 异步代码（setTimeout）\nconsole.log('开始');\nsetTimeout(function() {\n    console.log('异步执行');\n}, 1000);\nconsole.log('结束');\n\n// 回调函数示例\nfunction fetchData(callback) {\n    setTimeout(function() {\n        let data = { name: '张三', age: 25 };\n        callback(data);\n    }, 1000);\n}\n\nfetchData(function(data) {\n    console.log('获取到数据:', data);\n});\n\n// 回调地狱（不推荐）\ngetData(function(data1) {\n    processData(data1, function(data2) {\n        saveData(data2, function(result) {\n            console.log(result);\n        });\n    });\n});\n\n// 事件循环示例\nconsole.log('宏任务1');\nsetTimeout(() => console.log('宏任务2'), 0);\nPromise.resolve().then(() => console.log('微任务1'));\nconsole.log('宏任务3');\n\n// 输出顺序：宏任务1 -> 宏任务3 -> 微任务1 -> 宏任务2",
    "et": "❌ 常见错误：在异步操作后立即使用结果",
    "ec": "异步操作的结果在回调函数外不可用，因为代码执行顺序不同步。",
    "q": [
      "解释同步和异步的区别",
      "编写一个模拟数据请求的函数",
      "理解并解释事件循环的执行顺序"
    ]
  },
  {
    "id": 25,
    "t": "Promise",
    "p": [
      "Promise是异步编程的解决方案",
      "三种状态：pending、fulfilled、rejected",
      "then()：处理成功结果",
      "catch()：处理错误",
      "finally()：无论成功失败都会执行",
      "Promise.all()：等待所有Promise完成",
      "Promise.race()：返回第一个完成的Promise"
    ],
    "c": "// 创建Promise\nlet promise = new Promise(function(resolve, reject) {\n    setTimeout(function() {\n        let success = true;\n        if (success) {\n            resolve('成功！');\n        } else {\n            reject('失败！');\n        }\n    }, 1000);\n});\n\n// 使用Promise\npromise\n    .then(function(result) {\n        console.log(result);\n        return result + ' 继续处理';\n    })\n    .then(function(data) {\n        console.log(data);\n    })\n    .catch(function(error) {\n        console.error(error);\n    })\n    .finally(function() {\n        console.log('完成');\n    });\n\n// Promise.all\nlet p1 = Promise.resolve('第一个');\nlet p2 = Promise.resolve('第二个');\nlet p3 = new Promise(resolve => setTimeout(() => resolve('第三个'), 1000));\n\nPromise.all([p1, p2, p3])\n    .then(results => console.log(results));\n\n// Promise.race\nPromise.race([p1, p3])\n    .then(result => console.log('最快的:', result));\n\n// 封装异步函数\nfunction fetchUser(id) {\n    return new Promise(function(resolve, reject) {\n        setTimeout(() => {\n            resolve({ id: id, name: '张三' });\n        }, 500);\n    });\n}\n\nfetchUser(1)\n    .then(user => console.log(user))\n    .catch(err => console.error(err));",
    "et": "❌ 常见错误：忘记处理错误",
    "ec": "没有添加catch()会导致未处理的Promise rejection错误，应该始终处理错误情况。",
    "q": [
      "使用Promise封装一个异步操作",
      "实现Promise.all处理多个异步请求",
      "对比回调函数和Promise的优缺点"
    ]
  },
  {
    "id": 26,
    "t": "async/await",
    "p": [
      "async：声明异步函数",
      "await：等待Promise完成",
      "async函数返回Promise",
      "使用try...catch处理错误",
      "比Promise更简洁的语法"
    ],
    "c": "// 基本用法\nasync function getData() {\n    let result = await fetchData();\n    console.log(result);\n}\n\n// async函数返回Promise\nasync function greet() {\n    return 'Hello!';\n}\ngreet().then(msg => console.log(msg));\n\n// 处理错误\nasync function fetchUser(id) {\n    try {\n        let response = await fetch(`/api/users/${id}`);\n        let user = await response.json();\n        return user;\n    } catch (error) {\n        console.error('获取用户失败:', error);\n        throw error;\n    }\n}\n\n// 并行执行\nasync function fetchMultiple() {\n    let [user, posts] = await Promise.all([\n        fetchUser(1),\n        fetchPosts(1)\n    ]);\n    console.log(user, posts);\n}\n\n// 顺序执行\nasync function fetchSequential() {\n    let user = await fetchUser(1);\n    let posts = await fetchPosts(user.id);\n    return { user, posts };\n}\n\n// await只能在async函数中使用\nasync function main() {\n    let data = await fetchData();\n    processData(data);\n}\nmain();\n\n// 异步函数表达式\nconst getWeather = async function(city) {\n    let response = await fetch(`/api/weather/${city}`);\n    return response.json();\n};",
    "et": "❌ 常见错误：在非async函数中使用await",
    "ec": "await关键字只能在async函数内部使用，在普通函数中使用会导致语法错误。",
    "q": [
      "使用async/await重写Promise代码",
      "实现一个异步数据加载函数",
      "使用try...catch处理异步错误"
    ]
  },
  {
    "id": 27,
    "t": "类与继承",
    "p": [
      "class：定义类",
      "constructor：构造函数",
      "extends：继承",
      "super：调用父类方法",
      "static：静态方法",
      "getter/setter：访问器"
    ],
    "c": "// 定义类\nclass Person {\n    constructor(name, age) {\n        this.name = name;\n        this.age = age;\n    }\n\n    greet() {\n        console.log(`你好，我是${this.name}`);\n    }\n\n    getInfo() {\n        return `${this.name}，${this.age}岁`;\n    }\n\n    static create(name, age) {\n        return new Person(name, age);\n    }\n}\n\n// 创建实例\nlet person = new Person('张三', 25);\nperson.greet();\nconsole.log(person.getInfo());\n\n// 继承\nclass Student extends Person {\n    constructor(name, age, grade) {\n        super(name, age);\n        this.grade = grade;\n    }\n\n    study() {\n        console.log(`${this.name}正在学习，年级：${this.grade}`);\n    }\n\n    getInfo() {\n        return `${super.getInfo()}，年级：${this.grade}`;\n    }\n}\n\nlet student = new Student('李四', 18, '高三');\nstudent.greet();\nstudent.study();\nconsole.log(student.getInfo());\n\n// 访问器\nclass User {\n    constructor(name) {\n        this._name = name;\n    }\n\n    get name() {\n        return this._name;\n    }\n\n    set name(value) {\n        if (value.length > 0) {\n            this._name = value;\n        }\n    }\n}\n\nlet user = new User('王五');\nconsole.log(user.name);\nuser.name = '赵六';\nconsole.log(user.name);",
    "et": "❌ 常见错误：忘记调用super()",
    "ec": "在子类的constructor中必须先调用super()才能使用this，否则会抛出错误。",
    "q": [
      "创建一个汽车类，包含品牌、颜色、速度属性",
      "创建一个电动车子类继承汽车类",
      "添加静态方法和访问器"
    ]
  },
  {
    "id": 28,
    "t": "模块化",
    "p": [
      "import：导入模块",
      "export：导出模块",
      "默认导出和命名导出",
      "模块作用域：变量不污染全局",
      "type=\"module\"：启用模块化"
    ],
    "c": "// math.js - 模块文件\nexport const PI = 3.14159;\n\nexport function add(a, b) {\n    return a + b;\n}\n\nexport function multiply(a, b) {\n    return a * b;\n}\n\nexport default function divide(a, b) {\n    return a / b;\n}\n\n// main.js - 主文件\nimport divide, { PI, add, multiply } from './math.js';\n\nconsole.log(PI);           // 3.14159\nconsole.log(add(2, 3));    // 5\nconsole.log(multiply(2, 3)); // 6\nconsole.log(divide(6, 2));  // 3\n\n// 重命名导入\nimport { add as sum } from './math.js';\nconsole.log(sum(10, 20));  // 30\n\n// 导入所有\nimport * as math from './math.js';\nconsole.log(math.PI);\nconsole.log(math.add(1, 2));\n\n// 动态导入\nasync function loadModule() {\n    let module = await import('./math.js');\n    console.log(module.add(5, 5));\n}\nloadModule();\n\n// 导出多个\nexport { PI, add, multiply };",
    "et": "❌ 常见错误：忘记设置type=\"module\"",
    "ec": "在HTML中使用import/export时，需要在script标签上添加type=\"module\"属性。",
    "q": [
      "创建一个工具模块，导出常用函数",
      "在主文件中导入并使用模块",
      "实现动态导入"
    ]
  },
  {
    "id": 29,
    "t": "箭头函数",
    "p": [
      "=&gt;：箭头函数语法",
      "没有自己的this",
      "不能作为构造函数",
      "没有arguments对象",
      "简洁的语法：单行函数省略return",
      "适合作为回调函数"
    ],
    "c": "// 基本语法\nconst add = (a, b) => a + b;\nconsole.log(add(2, 3));  // 5\n\n// 单行函数自动返回\nconst square = x => x * x;\nconsole.log(square(4));  // 16\n\n// 多行函数需要花括号和return\nconst multiply = (a, b) => {\n    let result = a * b;\n    return result;\n};\n\n// 无参数\nconst greet = () => console.log('Hello!');\n\n// 一个参数可以省略括号\nconst double = x => x * 2;\n\n// 返回对象需要括号\nconst createUser = (name, age) => ({ name, age });\n\n// 保持this指向\nlet person = {\n    name: '张三',\n    greet: function() {\n        setTimeout(() => {\n            console.log(this.name);  // 张三\n        }, 1000);\n    }\n};\nperson.greet();\n\n// 数组方法中使用\nlet numbers = [1, 2, 3, 4];\nlet doubled = numbers.map(x => x * 2);\nlet evens = numbers.filter(x => x % 2 === 0);\nlet sum = numbers.reduce((acc, x) => acc + x, 0);\n\nconsole.log(doubled);  // [2, 4, 6, 8]\nconsole.log(evens);    // [2, 4]\nconsole.log(sum);      // 10",
    "et": "❌ 常见错误：在对象方法中使用箭头函数",
    "ec": "对象方法中使用箭头函数会导致this指向全局对象（浏览器中是window），而不是对象本身。",
    "q": [
      "使用箭头函数重写普通函数",
      "在数组方法中使用箭头函数",
      "理解箭头函数中this的指向"
    ]
  },
  {
    "id": 30,
    "t": "解构赋值",
    "p": [
      "数组解构：从数组提取值",
      "对象解构：从对象提取属性",
      "默认值：设置解构默认值",
      "重命名：解构时重命名变量",
      "嵌套解构：解构嵌套结构",
      "剩余运算符：...收集剩余元素"
    ],
    "c": "// 数组解构\nlet [a, b] = [1, 2];\nconsole.log(a, b);  // 1 2\n\n// 跳过元素\nlet [x, , y] = [1, 2, 3];\nconsole.log(x, y);  // 1 3\n\n// 默认值\nlet [p, q = 10] = [5];\nconsole.log(p, q);  // 5 10\n\n// 剩余运算符\nlet [first, ...rest] = [1, 2, 3, 4];\nconsole.log(first);  // 1\nconsole.log(rest);   // [2, 3, 4]\n\n// 对象解构\nlet { name, age } = { name: '张三', age: 25 };\nconsole.log(name, age);\n\n// 重命名\nlet { name: userName, age: userAge } = { name: '李四', age: 30 };\nconsole.log(userName, userAge);\n\n// 默认值\nlet { city = '北京' } = { name: '王五' };\nconsole.log(city);  // 北京\n\n// 嵌套解构\nlet user = {\n    name: '赵六',\n    address: {\n        city: '上海',\n        street: '南京路'\n    }\n};\nlet { name: n, address: { city: c } } = user;\nconsole.log(n, c);  // 赵六 上海\n\n// 函数参数解构\nfunction greet({ name, age }) {\n    console.log(`你好，${name}，${age}岁`);\n}\ngreet({ name: '钱七', age: 28 });\n\n// 交换变量\nlet m = 1, n = 2;\n[m, n] = [n, m];\nconsole.log(m, n);  // 2 1",
    "et": "❌ 常见错误：解构未定义的变量",
    "ec": "解构null或undefined会抛出错误，应该确保被解构的值存在。",
    "q": [
      "从数组中提取前三个元素",
      "从对象中提取多个属性并设置默认值",
      "实现函数参数解构"
    ]
  },
  {
    "id": 31,
    "t": "展开运算符",
    "p": [
      "...：展开运算符",
      "展开数组：将数组元素展开",
      "展开对象：将对象属性展开",
      "复制数组/对象：创建浅拷贝",
      "合并数组/对象：组合多个结构",
      "函数参数展开：传递数组作为参数"
    ],
    "c": "// 展开数组\nlet arr1 = [1, 2, 3];\nlet arr2 = [...arr1, 4, 5];\nconsole.log(arr2);  // [1, 2, 3, 4, 5]\n\n// 复制数组\nlet copy = [...arr1];\nconsole.log(copy);  // [1, 2, 3]\n\n// 合并数组\nlet merged = [...arr1, ...arr2];\nconsole.log(merged);\n\n// 函数参数展开\nlet numbers = [1, 2, 3];\nconsole.log(Math.max(...numbers));  // 3\n\n// 展开对象\nlet obj1 = { a: 1, b: 2 };\nlet obj2 = { ...obj1, c: 3 };\nconsole.log(obj2);  // { a: 1, b: 2, c: 3 }\n\n// 复制对象\nlet objCopy = { ...obj1 };\n\n// 合并对象（后面的会覆盖前面的）\nlet combined = { ...obj1, ...{ b: 4, c: 5 } };\nconsole.log(combined);  // { a: 1, b: 4, c: 5 }\n\n// 添加新属性\nlet user = { name: '张三', age: 25 };\nlet updatedUser = { ...user, age: 26, city: '北京' };\nconsole.log(updatedUser);\n\n// 与解构结合\nlet [first, ...rest] = [1, 2, 3, 4];\nconsole.log(first, rest);  // 1 [2, 3, 4]",
    "et": "❌ 常见错误：展开运算符只能展开可迭代对象",
    "ec": "展开运算符只能用于数组或类数组对象，不能用于普通对象（除非在对象字面量中）。",
    "q": [
      "合并两个数组并去重",
      "复制对象并添加新属性",
      "使用展开运算符调用函数"
    ]
  },
  {
    "id": 32,
    "t": "Map 与 Set",
    "p": [
      "Map：键值对集合，键可以是任意类型",
      "Set：唯一值集合",
      "Map方法：set、get、has、delete、clear",
      "Set方法：add、has、delete、clear",
      "遍历：forEach、for...of",
      "size属性：获取元素数量"
    ],
    "c": "// Map 使用\nlet map = new Map();\n\n// 添加键值对\nmap.set('name', '张三');\nmap.set('age', 25);\nmap.set(true, '是');\nmap.set({ id: 1 }, '对象键');\n\n// 获取值\nconsole.log(map.get('name'));  // 张三\nconsole.log(map.get(true));    // 是\n\n// 检查键是否存在\nconsole.log(map.has('age'));   // true\n\n// 删除键值对\nmap.delete('age');\n\n// 遍历 Map\nmap.forEach(function(value, key) {\n    console.log(key + ': ' + value);\n});\n\nfor (let [key, value] of map) {\n    console.log(key, value);\n}\n\n// Set 使用\nlet set = new Set();\n\n// 添加值\nset.add(1);\nset.add(2);\nset.add(2);  // 重复值会被忽略\nset.add('hello');\n\n// 检查值是否存在\nconsole.log(set.has(2));  // true\n\n// 删除值\nset.delete(1);\n\n// 遍历 Set\nset.forEach(function(value) {\n    console.log(value);\n});\n\nfor (let value of set) {\n    console.log(value);\n}\n\n// 数组去重\nlet arr = [1, 2, 2, 3, 3, 3];\nlet unique = [...new Set(arr)];\nconsole.log(unique);  // [1, 2, 3]\n\n// 交集、并集、差集\nlet set1 = new Set([1, 2, 3]);\nlet set2 = new Set([3, 4, 5]);\n\nlet union = new Set([...set1, ...set2]);\nlet intersection = new Set([...set1].filter(x => set2.has(x)));\nlet difference = new Set([...set1].filter(x => !set2.has(x)));\n\nconsole.log(union);           // {1, 2, 3, 4, 5}\nconsole.log(intersection);    // {3}\nconsole.log(difference);      // {1, 2}",
    "et": "❌ 常见错误：使用点号访问Map值",
    "ec": "Map的键值对不能使用点号访问，必须使用get()和set()方法。",
    "q": [
      "使用Map存储用户信息",
      "实现数组去重",
      "计算两个数组的交集和并集"
    ]
  },
  {
    "id": 33,
    "t": "正则表达式",
    "p": [
      "/pattern/flags：正则表达式字面量",
      "test()：测试字符串是否匹配",
      "match()：查找匹配项",
      "replace()：替换匹配项",
      "常用标志：g（全局）、i（忽略大小写）、m（多行）",
      "元字符：.、^、$、*、+、?、[]、()",
      "量词：*、+、?、{n}、{n,}、{n,m}"
    ],
    "c": "// 创建正则表达式\nlet regex1 = /hello/;\nlet regex2 = new RegExp('hello');\n\n// 测试匹配\nconsole.log(regex1.test('hello world'));  // true\n\n// 查找匹配\nlet str = 'hello world, hello javascript';\nlet matches = str.match(/hello/g);\nconsole.log(matches);  // ['hello', 'hello']\n\n// 替换\nlet replaced = str.replace(/hello/g, 'hi');\nconsole.log(replaced);  // 'hi world, hi javascript'\n\n// 忽略大小写\nconsole.log(/hello/i.test('Hello'));  // true\n\n// 元字符\nlet emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$/;\nconsole.log(emailRegex.test('test@example.com'));  // true\n\n// 提取分组\nlet dateRegex = /(\\d{4})-(\\d{2})-(\\d{2})/;\nlet dateStr = '2024-01-15';\nlet groups = dateStr.match(dateRegex);\nconsole.log(groups[1]);  // 2024\nconsole.log(groups[2]);  // 01\nconsole.log(groups[3]);  // 15\n\n// 量词\nconsole.log(/a{2}/.test('aa'));    // true\nconsole.log(/a{2,}/.test('aaa'));  // true\nconsole.log(/a{2,4}/.test('aaaa')); // true\n\n// 字符类\nconsole.log(/[abc]/.test('a'));  // true\nconsole.log(/[^abc]/.test('d')); // true\nconsole.log(/\\d+/.test('123'));  // true\nconsole.log(/\\w+/.test('hello')); // true\nconsole.log(/\\s+/.test(' '));    // true",
    "et": "❌ 常见错误：忘记添加全局标志g",
    "ec": "使用match()时，如果没有g标志，只会返回第一个匹配项。",
    "q": [
      "验证邮箱格式",
      "验证手机号码",
      "提取字符串中的所有数字"
    ]
  },
  {
    "id": 34,
    "t": "HTTP 请求",
    "p": [
      "fetch API：现代HTTP请求方式",
      "GET：获取数据",
      "POST：提交数据",
      "响应处理：json()、text()、blob()",
      "请求选项：headers、body、method",
      "错误处理：检查ok属性"
    ],
    "c": "// GET 请求\nfetch('https://api.example.com/users')\n    .then(response => response.json())\n    .then(data => console.log(data))\n    .catch(error => console.error('请求失败:', error));\n\n// POST 请求\nfetch('https://api.example.com/users', {\n    method: 'POST',\n    headers: {\n        'Content-Type': 'application/json'\n    },\n    body: JSON.stringify({\n        name: '张三',\n        age: 25\n    })\n})\n.then(response => response.json())\n.then(data => console.log('创建成功:', data))\n.catch(error => console.error('创建失败:', error));\n\n// async/await 方式\nasync function fetchUsers() {\n    try {\n        let response = await fetch('https://api.example.com/users');\n        if (!response.ok) {\n            throw new Error('HTTP错误: ' + response.status);\n        }\n        let data = await response.json();\n        return data;\n    } catch (error) {\n        console.error('获取用户失败:', error);\n    }\n}\n\n// 发送表单数据\nlet formData = new FormData();\nformData.append('username', '张三');\nformData.append('avatar', fileInput.files[0]);\n\nfetch('/upload', {\n    method: 'POST',\n    body: formData\n})\n.then(response => response.text())\n.then(result => console.log(result));\n\n// 设置请求头\nfetch('/api/data', {\n    headers: {\n        'Authorization': 'Bearer ' + token,\n        'Accept': 'application/json'\n    }\n})\n.then(response => response.json());\n\n// 处理不同响应类型\nfetch('/api/image')\n.then(response => response.blob())\n.then(blob => {\n    let url = URL.createObjectURL(blob);\n    img.src = url;\n});",
    "et": "❌ 常见错误：忘记检查响应状态",
    "ec": "fetch只有在网络错误时才会reject，HTTP错误（如404、500）不会触发catch，需要检查response.ok。",
    "q": [
      "使用fetch获取API数据",
      "实现用户登录功能",
      "上传文件到服务器"
    ]
  },
  {
    "id": 35,
    "t": "性能优化与最佳实践",
    "p": [
      "防抖和节流：优化事件处理",
      "懒加载：延迟加载图片",
      "代码分割：按需加载模块",
      "缓存：减少重复请求",
      "减少DOM操作：批量更新",
      "使用requestAnimationFrame：优化动画",
      "避免内存泄漏：清理事件监听"
    ],
    "c": "// 防抖函数\nfunction debounce(func, wait) {\n    let timeout;\n    return function() {\n        clearTimeout(timeout);\n        timeout = setTimeout(func, wait);\n    };\n}\n\nlet debouncedSearch = debounce(search, 300);\ninput.addEventListener('input', debouncedSearch);\n\n// 节流函数\nfunction throttle(func, limit) {\n    let inThrottle;\n    return function() {\n        if (!inThrottle) {\n            func();\n            inThrottle = true;\n            setTimeout(() => inThrottle = false, limit);\n        }\n    };\n}\n\nlet throttledScroll = throttle(handleScroll, 100);\nwindow.addEventListener('scroll', throttledScroll);\n\n// 懒加载图片\nfunction lazyLoad() {\n    let images = document.querySelectorAll('img[data-src]');\n    images.forEach(img => {\n        if (img.getBoundingClientRect().top < window.innerHeight) {\n            img.src = img.dataset.src;\n            img.removeAttribute('data-src');\n        }\n    });\n}\nwindow.addEventListener('scroll', lazyLoad);\n\n// 使用requestAnimationFrame\nfunction animate(element, targetPosition) {\n    function step() {\n        let current = element.offsetLeft;\n        if (current < targetPosition) {\n            element.style.left = current + 1 + 'px';\n            requestAnimationFrame(step);\n        }\n    }\n    requestAnimationFrame(step);\n}\n\n// 批量DOM操作\nfunction appendItems(items) {\n    let fragment = document.createDocumentFragment();\n    items.forEach(item => {\n        let div = document.createElement('div');\n        div.textContent = item;\n        fragment.appendChild(div);\n    });\n    container.appendChild(fragment);\n}\n\n// 事件监听清理\nclass Component {\n    constructor() {\n        this.handler = this.handleClick.bind(this);\n        document.addEventListener('click', this.handler);\n    }\n    \n    destroy() {\n        document.removeEventListener('click', this.handler);\n    }\n}\n\n// 使用WeakMap缓存\nconst cache = new WeakMap();\nfunction expensiveOperation(obj) {\n    if (cache.has(obj)) {\n        return cache.get(obj);\n    }\n    let result = // 计算...\n    cache.set(obj, result);\n    return result;\n}",
    "et": "❌ 常见错误：频繁操作DOM",
    "ec": "每次DOM操作都会触发重排和重绘，应该批量操作或使用DocumentFragment。",
    "q": [
      "实现搜索输入框的防抖",
      "实现图片懒加载",
      "优化滚动事件处理"
    ]
  }
];
